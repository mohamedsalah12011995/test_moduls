﻿using Core.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto.MissingItem;
using Nupco.Core.Dto.Safety.MissingItem;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System.Linq.Expressions;

namespace Nupco.EF.Repositories
{
    internal class MissingItemReportRepository : BaseRepository<MissingItemReport>, IMissingItemReportRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly MissingItemReport_Assembler _MissingItemReport_Assembler;

        private string[] stringArray = { "HandledByUser", "CreatedByUser", "UpdatedByUser", "MissingItemAttachments" };


        public MissingItemReportRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _MissingItemReport_Assembler = new MissingItemReport_Assembler();
            _logger = logger;
            _context = context;

        }

        public async Task<OperationOutput> HandleMissingItem(int id, string userId, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsHandled = activate;
                find.HandledBy = userId;
                find.HandledDate = DateTime.Now;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }
        public async Task<OperationOutput> ApprovedOrUnApproved(int id, bool approved)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsApproved = approved;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                //find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(MissingItemReportObjDto entity)
        {
            try
            {
                var model = _MissingItemReport_Assembler.WriteDal(entity);
                model.IsHandled = false;
                model.CreatedDate = Dates.ConvertToTimeOnly(entity.CreatedDate);
                var _attachments = new List<MissingItemAttachment>();


                if (entity.Attachments != null)
                {
                    foreach (var item in entity.Attachments)
                    {
                        var attachment = new MissingItemAttachment
                        {
                            MissingItemReportId = model.Id
                        };

                        if (!string.IsNullOrEmpty(item.OriginalPicBase64))
                        {
                            attachment.OrignalFile =
                                Images.SaveSingleImageOnServer(
                                    item.OriginalPicBase64,
                                    1024,
                                    entity.pathToSave,
                                    false,
                                    0,
                                    entity.pathToSave);
                        }

                        if (!string.IsNullOrEmpty(item.OriginalVideoBase64))
                        {
                            attachment.OrignalFile =
                                Images.UploadVideoFileNew(
                                    item.OriginalVideoBase64,
                                    entity.pathToSave);
                        }

                        _attachments.Add(attachment);
                    }
                    model.MissingItemAttachments= _attachments;

                }

                await _context.MissingItemReports.AddAsync(model);
                await _context.SaveChangesAsync();

                var entityObj = _MissingItemReport_Assembler.WriteDto(model);

                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(entityObj, 1);
                return _result;
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDeleted = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FilterBy _filter)
        {
            try
            {
                var spec = Specification<MissingItemReport>.All.And(new MissingItemReportSpecification(_filter));

                var MissingItemReport = await FindAllAsync(spec.ToExpression(), (int)_filter.pageNumber * (int)_filter.pageSize, (int)_filter.pageSize,stringArray);
                var _MissingItemReport = _MissingItemReport_Assembler.WriteListDto(MissingItemReport.Where(i=> i.IsDeleted==false));
                var counts = await CountAsync(i => i.IsDeleted == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_MissingItemReport, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false, stringArray);
                var _entities = _MissingItemReport_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var MissingItemReport = await FindAsync(i=> i.Id==id , stringArray);
                if (MissingItemReport != null)
                {
                    var _MissingItemReport = _MissingItemReport_Assembler.WriteDto(MissingItemReport);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_MissingItemReport, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> UpdateMissingItemReportComment(MissingItemReportComment entity)
        {
            try
            {
                var _entity = await _context.MissingItemReports
                    .Include(x => x.MissingItemAttachments)
                    .FirstOrDefaultAsync(x => x.Id == entity.Id);

                if (_entity is null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                _entity.Comment = entity.Comment;
                Update(_entity);

                await _context.SaveChangesAsync();

                var dto = _MissingItemReport_Assembler.WriteDto(_entity);

                return new ResultOutputData()
                    .GenearetResultOutput(dto, 1);
            }
            catch (Exception)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }


        public async Task<OperationOutput> UpdateEntity(MissingItemReportObjDto entity)
        {
            try
            {
                if (!entity.Id.HasValue)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                var _entity = await _context.MissingItemReports
                    .Include(x => x.MissingItemAttachments)
                    .FirstOrDefaultAsync(x => x.Id == entity.Id.Value);

                if (_entity is null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                _entity.Note = entity.Note;
                _entity.MissingType = entity.MissingType;
                _entity.UpdatedDate = Dates.ConvertToTimeOnly(entity.CreatedDate);


                var incomingAttachments = entity.Attachments ?? new List<MissingItemAttachmentObjDto>();

                var toRemove = _entity.MissingItemAttachments
                    .Where(dbAtt => !incomingAttachments.Any(dtoAtt => dtoAtt.Id == dbAtt.Id))
                    .ToList();

                foreach (var removeItem in toRemove)
                {
                    _context.Remove(removeItem);

                }

                var newAttachments = incomingAttachments
                    .Where(x => !string.IsNullOrEmpty(x.OriginalPicBase64))
                    .ToList();

                foreach (var newItem in newAttachments)
                {
                    var attachment = new MissingItemAttachment
                    {
                        OrignalFile = Images.SaveSingleImageOnServer(
                            newItem.OriginalPicBase64,
                            1024,
                            entity.pathToSave,
                            false,
                            0,
                            entity.pathToSave)
                    };

                    _entity.MissingItemAttachments.Add(attachment);
                }

                await _context.SaveChangesAsync();

                var dto = _MissingItemReport_Assembler.WriteDto(_entity);

                return new ResultOutputData()
                    .GenearetResultOutput(dto, 1);
            }
            catch (Exception)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetAllByUserId(string userId)
        {
            try
            {
                Expression<Func<MissingItemReport, bool>> filter = i =>
                    i.IsDeleted == false && (i.CreatedBy == userId || i.IsApproved == true);

                var entities = await FindAllAsync(filter, stringArray);
                var _entities = _MissingItemReport_Assembler.WriteListDto(entities.OrderByDescending(o => o.CreatedDate)).ToList();

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(filter);

                return resultOutput.GenearetResultOutput(_entities, count);
            }
            catch
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }

        }


        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(MissingItemReportDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<MissingItemReportDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<MissingItemReportDto> entities)
        {
            throw new NotImplementedException();
        }

        public Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            throw new NotImplementedException();
        }

    }
}
