﻿using Core.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto.Safety.Observation;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;

namespace Nupco.EF.Repositories
{
    internal class ObservationReportRepository : BaseRepository<ObservationReport>, IObservationReportRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly ObservationReport_Assembler _ObservationReport_Assembler;

        private string[] stringArray = { "HandledByUser", "CreatedByUser", "ObservationAttachments" };


        public ObservationReportRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _ObservationReport_Assembler = new ObservationReport_Assembler();
            _logger = logger;
            _context = context;

        }

        public async Task<OperationOutput> HandleObservation(int id, string userId, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsHandled = activate;
                find.HandleBy = userId;
                find.HandleDate = DateTime.Now;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> ApprovedOrUnApproved(int id, bool approved)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsApproved = approved;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(ObservationReportObjDto entity)
        {
            try
            {
                var model = _ObservationReport_Assembler.WriteDal(entity);

                model.IsHandled = false;
                model.IsDelete = false;
                model.CreatedDate = Dates.ConvertToTimeOnly(entity.CreatedDate);

                model.ObservationAttachments = new List<ObservationAttachment>();

                if (entity.Attachments != null)
                {
                    foreach (var item in entity.Attachments)
                    {
                        var attachment = new ObservationAttachment
                        {
                            ObservationReportId = model.Id
                        };

                        if (!string.IsNullOrEmpty(item.OriginalPicBase64))
                        {
                            attachment.OrignalFile =
                                Images.SaveSingleImageOnServer(
                                    item.OriginalPicBase64,
                                    1024,
                                    entity.pathToSave,
                                    false,
                                    0,
                                    entity.pathToSave);
                        }

                        if (!string.IsNullOrEmpty(item.OriginalVideoBase64))
                        {
                            attachment.OrignalFile =
                                Images.UploadVideoFileNew(
                                    item.OriginalVideoBase64,
                                    entity.pathToSave);
                        }

                        model.ObservationAttachments.Add(attachment);
                    }
                }

                await _context.ObservationReports.AddAsync(model);
                await _context.SaveChangesAsync();

                var entityObj = _ObservationReport_Assembler.WriteDto(model);

                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(entityObj, 1);
                return _result;
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDelete = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FilterBy _filter)
        {
            try
            {
                var spec = Specification<ObservationReport>.All.And(new ObservationReportSpecification(_filter));

                var ObservationReport = await FindAllAsync(spec.ToExpression(), (int)_filter.pageNumber * (int)_filter.pageSize, (int)_filter.pageSize,stringArray);
                var _ObservationReport = _ObservationReport_Assembler.WriteListDto(ObservationReport.Where(i=> i.IsDelete==false));
                var counts = await CountAsync(i => i.IsDelete == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_ObservationReport, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDelete == false, stringArray);
                var _entities = _ObservationReport_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDelete == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }
        public async Task<OperationOutput> GetAllByUserId(string userId)
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDelete == false && i.CreatedBy == userId, stringArray);
                var _entities = _ObservationReport_Assembler.WriteListDto(entities.OrderByDescending(o=> o.CreatedDate)).ToList();

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDelete == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }


        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var ObservationReport = await FindAsync(i=> i.Id==id , stringArray);
                if (ObservationReport != null)
                {
                    var _ObservationReport = _ObservationReport_Assembler.WriteDto(ObservationReport);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_ObservationReport, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> UpdateObservationReportComment(ObservationReportComment entity)
        {
            try
            {

                var _entity = await _context.ObservationReports
                    .Include(x => x.ObservationAttachments)
                    .FirstOrDefaultAsync(x => x.Id == entity.Id);

                if (_entity is null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                _entity.Comment = entity.Comment;
                Update(_entity);
                await _context.SaveChangesAsync();

                var dto = _ObservationReport_Assembler.WriteDto(_entity);

                return new ResultOutputData()
                    .GenearetResultOutput(dto, 1);
            }
            catch (Exception)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }


        public async Task<OperationOutput> UpdateEntity(ObservationReportObjDto entity)
        {
            try
            {
                if (!entity.Id.HasValue)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                var _entity = await _context.ObservationReports
                    .Include(x => x.ObservationAttachments)
                    .FirstOrDefaultAsync(x => x.Id == entity.Id.Value);

                if (_entity is null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                _entity.Note = entity.Note;
                _entity.UpdatedDate = Dates.ConvertToTimeOnly(entity.CreatedDate);



                var incomingAttachments = entity.Attachments ?? new List<ObservationAttachmentObjDto>();

                var toRemove = _entity.ObservationAttachments
                    .Where(dbAtt => !incomingAttachments.Any(dtoAtt => dtoAtt.Id == dbAtt.Id))
                    .ToList();

                foreach (var removeItem in toRemove)
                {
                    _context.Remove(removeItem);

                }

                var newAttachments = incomingAttachments
                    .Where(x => !string.IsNullOrEmpty(x.OriginalPicBase64))
                    .ToList();

                foreach (var newItem in newAttachments)
                {
                    var attachment = new ObservationAttachment
                    {
                        OrignalFile = Images.SaveSingleImageOnServer(
                            newItem.OriginalPicBase64,
                            1024,
                            entity.pathToSave,
                            false,
                            0,
                            entity.pathToSave)
                    };

                    _entity.ObservationAttachments.Add(attachment);
                }

                await _context.SaveChangesAsync();

                var dto = _ObservationReport_Assembler.WriteDto(_entity);

                return new ResultOutputData()
                    .GenearetResultOutput(dto, 1);
            }
            catch (Exception)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(ObservationReportDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<ObservationReportDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<ObservationReportDto> entities)
        {
            throw new NotImplementedException();
        }

        public Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            throw new NotImplementedException();
        }

        public Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            throw new NotImplementedException();
        }
    }
}
