﻿using Core.Helpers;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto.Safety.Emergency;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;

namespace Nupco.EF.Repositories
{
    internal class EmergencyAlertRepository : BaseRepository<EmergencyAlert>, IEmergencyAlertRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly EmergencyAlert_Assembler _EmergencyAlert_Assembler;

        private string[] stringArray = { "CreatedByUser", "UpdatedByUser" };


        public EmergencyAlertRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _EmergencyAlert_Assembler = new EmergencyAlert_Assembler();
            _logger = logger;
            _context = context;

        }
        public async Task<OperationOutput> ResolvedOrUnResolved(int id, bool resolve)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsResolved = resolve;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(EmergencyAlertObjDto entity)
        {
            try
            {

                var _model = _EmergencyAlert_Assembler.WriteDal(entity);
                _model.IsActive = true;
                _model.IsDelete = false;
                _model.CreatedDate = DateTime.Now;
                var _entity = await AddAsync(_model);
                await _context.SaveChangesAsync();


                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(_entity, 1);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDelete = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            try
            {
                var spec = Specification<EmergencyAlert>.All.And(new EmergencyAlertSpecification(_filter));

                var EmergencyAlert = await FindAllAsync(i => i.IsDelete == false, (int)_filter.pageNumber * (int)_filter.pageSize, (int)_filter.pageSize,stringArray);
                var _EmergencyAlert = _EmergencyAlert_Assembler.WriteListDto(EmergencyAlert);
                var counts = await CountAsync(i => i.IsDelete == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_EmergencyAlert, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDelete == false, stringArray);
                var _entities = _EmergencyAlert_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDelete == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var EmergencyAlert = await GetByIdAsync(id);
                if (EmergencyAlert != null)
                {
                    var _EmergencyAlert = _EmergencyAlert_Assembler.WriteDto(EmergencyAlert);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_EmergencyAlert, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> UpdateEntity(EmergencyAlertObjDto entity)
        {
            try
            {

                var _entity = await FindAsync(i => i.Id == entity.Id);
                if (_entity is not null)
                {
                    _entity.IsActive = true;
                    _entity.IsDelete = false;
                    _entity.TitleAr = entity.TitleAr;
                    _entity.TitleEn = entity.TitleEn;
                    _entity.DescriptionAr = entity.DescriptionAr;
                    _entity.DescriptionEn = entity.DescriptionEn;
                    _entity.UpdatedDate = DateTime.Now;

                    var _model =  Update(_entity);
                    await SaveChangesAsync();

                    ResultOutputData resultOutput = new ResultOutputData();
                    var _result = resultOutput.GenearetResultOutput(_model, 1);
                    return _result;
                }

                else
                {
                    var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return Result;
                }

            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }


        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(EmergencyAlertDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<EmergencyAlertDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<EmergencyAlertDto> entities)
        {
            throw new NotImplementedException();
        }
    }
}
