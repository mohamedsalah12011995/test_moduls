﻿using Core.Helpers;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core.Consts;
using Nupco.Core.Dto.ChatbotHistory;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models.ChatbotHistories;
using System.Data;

namespace Nupco.EF.Repositories
{
    public class ChatBotHistoryRepository : BaseRepository<ChatbotHistory>, IChatbotHistoryRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;

        public ChatBotHistoryRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            this._logger = logger;
            this._context = context;
        }

        private async Task<IDbConnection> GetOpenConnectionAsync()
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != ConnectionState.Open)
            {
                await connection.OpenAsync();
            }
            return connection;
        }

        #region Level 1: Executive View
        public async Task<OperationOutput> GetExecutiveSummary()
        {
            try
            {
                var db = await GetOpenConnectionAsync();

                const string sql = @"
    -- 1. الإحصائيات العامة (تم تحديث عداد المستخدمين ليشمل الزوار المجهولين كعنصر فريد)
    SELECT 
        COUNT(*) as TotalRequests,
        SUM(CASE WHEN IsSuccess = 1 THEN 1 ELSE 0 END) as SuccessCount,
        AVG(CASE WHEN ISJSON(Answer) > 0 THEN CAST(JSON_VALUE(Answer, '$.top_score') AS FLOAT) ELSE NULL END) as AvgAccuracy,
        COUNT(DISTINCT ISNULL(UserId, 'Guest')) as ActiveUsers
    FROM ChatbotHistories;

    -- 2. جلب الأسماء الفريدة
    SELECT DISTINCT 
        CASE 
            WHEN h.UserId IS NULL THEN 'Guest / Anonymous'
            ELSE ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, '') 
        END as EmployeeName
    FROM ChatbotHistories h
    LEFT JOIN AspNetUsers u ON h.UserId = u.Id;";

                using (var multi = await db.QueryMultipleAsync(sql))
                {
                    var summary = await multi.ReadFirstOrDefaultAsync<dynamic>();
                    var userNames = await multi.ReadAsync<string>();

                    var finalResult = new
                    {
                        Summary = summary,
                        ActiveUserList = userNames
                    };

                    ResultOutputData resultOutput = new ResultOutputData();
                    return resultOutput.GenearetResultOutput(finalResult, 1);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetExecutiveSummary");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        #endregion

        #region Level 2: Tactical View
        public async Task<object> GetTacticalInsights()
        {
            try
            {
                var db = await GetOpenConnectionAsync();

                const string sql = @"
                    -- 1. الفجوات المعرفية (أسئلة دقتها منخفضة)
                    SELECT TOP 10 Question, CAST(JSON_VALUE(Answer, '$.top_score') AS FLOAT) as Score
                    FROM ChatbotHistories
                    WHERE IsSuccess = 1 AND CAST(JSON_VALUE(Answer, '$.top_score') AS FLOAT) < 0.4
                    ORDER BY Score DESC;

                    -- 2. المصادر الأكثر استخداماً
                    SELECT TOP 5 
                        ISNULL(JSON_VALUE(Answer, '$.sources[0].title'), 'Unknown Source') as Document, 
                        COUNT(*) as UsageCount
                    FROM ChatbotHistories
                    WHERE IsSuccess = 1 AND Answer IS NOT NULL
                    GROUP BY JSON_VALUE(Answer, '$.sources[0].title')
                    ORDER BY UsageCount DESC;

                    -- 3. أعلى 5 إدارات استخداماً (تم تحويلها إلى LEFT JOIN لتشمل العمليات التي ليس لها مستخدم)
                    SELECT TOP 5 
                        ISNULL(u.DepartmentName, 'Unassigned / Guests') as Department, 
                        COUNT(*) as UsageCount
                    FROM ChatbotHistories h
                    LEFT JOIN AspNetUsers u ON h.UserId = u.Id
                    GROUP BY u.DepartmentName
                    ORDER BY UsageCount DESC;";

                using (var multi = await db.QueryMultipleAsync(sql))
                {
                    var gaps = await multi.ReadAsync<dynamic>();
                    var topSources = await multi.ReadAsync<dynamic>();
                    var topDepartments = await multi.ReadAsync<dynamic>();

                    return new { gaps, topSources, topDepartments };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetTacticalInsights");
                return null;
            }
        }
        #endregion

        #region Level 3: Operational View
        public async Task<OperationOutput> GetOperationalStatus()
        {
            try
            {
                var db = await GetOpenConnectionAsync();

                const string sql = @"
    -- 1. إحصائيات الأداء مع تحويل وحساب دقيق للملي ثانية (Milliseconds) مع الكسور
    SELECT CASE 
        WHEN DurationMilliseconds <= 1000 THEN 'Green'
        WHEN DurationMilliseconds <= 3000 THEN 'Yellow'
        ELSE 'Red' END as Label, 
        COUNT(*) as Count,
        -- تم التعديل هنا: عمل CAST إلى FLOAT للحصول على قيمة دقيقة بالملي ثانية ومقربة
        ROUND(AVG(CAST(DurationMilliseconds AS FLOAT)), 1) as AvgDurationMilliseconds
    FROM ChatbotHistories 
    GROUP BY CASE 
        WHEN DurationMilliseconds <= 1000 THEN 'Green'
        WHEN DurationMilliseconds <= 3000 THEN 'Yellow'
        ELSE 'Red' END;

    -- 2. ساعات الذروة
    SELECT DATEPART(HOUR, CreatedDate) as Hour, COUNT(*) as Count
    FROM ChatbotHistories GROUP BY DATEPART(HOUR, CreatedDate) ORDER BY Hour;

    -- 3. توزيع الأخطاء
    SELECT StatusCode, COUNT(*) as Count 
    FROM ChatbotHistories WHERE StatusCode <> 200 GROUP BY StatusCode ORDER BY Count DESC;

    -- 4. إجمالي الطلبات (Total Requests) لكل منصة
    SELECT 
        CASE 
            WHEN SessionId LIKE 'portal%' THEN 'Portal'
            WHEN SessionId LIKE 'mobile%' THEN 'Mobile'
            ELSE 'Other' 
        END as Platform, 
        COUNT(*) as RequestCount
    FROM ChatbotHistories
    GROUP BY CASE 
        WHEN SessionId LIKE 'portal%' THEN 'Portal'
        WHEN SessionId LIKE 'mobile%' THEN 'Mobile'
        ELSE 'Other' 
    END;

    -- 5. نسبة الأسئلة الناجحة والفاشلة بناءً على IsSuccess
    SELECT 
        SUM(CASE WHEN IsSuccess = 1 THEN 1 ELSE 0 END) as AnsweredCount, 
        SUM(CASE WHEN IsSuccess = 0 OR IsSuccess IS NULL THEN 1 ELSE 0 END) as UnansweredCount
    FROM ChatbotHistories;";

                using (var multi = await db.QueryMultipleAsync(sql))
                {
                    var performance = await multi.ReadAsync<dynamic>();
                    var peaks = await multi.ReadAsync<dynamic>();
                    var errors = await multi.ReadAsync<dynamic>();
                    var platformSessions = await multi.ReadAsync<dynamic>();
                    var responseRatio = await multi.ReadFirstOrDefaultAsync<dynamic>();

                    ResultOutputData resultOutput = new ResultOutputData();
                    return resultOutput.GenearetResultOutput(new { performance, peaks, errors, platformSessions, responseRatio }, 5);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetOperationalStatus");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        #endregion

        #region Level 4: Advanced Questions
        public async Task<OperationOutput> GetRepeatedQuestionsReport()
        {
            try
            {
                var db = await GetOpenConnectionAsync();

                const string sql = @"
            SELECT TOP 15 
                Question, 
                COUNT(*) as Repeats, 
                AVG(CAST(JSON_VALUE(Answer, '$.top_score') AS FLOAT)) as AvgScore
            FROM ChatbotHistories
            WHERE ISJSON(Answer) > 0 
            GROUP BY Question
            HAVING COUNT(*) > 1
            ORDER BY Repeats DESC";

                var _entities = await db.QueryAsync<dynamic>(sql);
                ResultOutputData resultOutput = new ResultOutputData();

                return resultOutput.GenearetResultOutput(_entities, _entities.Count());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetRepeatedQuestionsReport");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        #endregion

        public async Task<OperationOutput> GetAllByPagenationAsync(FilterChatbotHistory filter)
        {
            try
            {
                var pageNumber = filter.pageNumber ?? 0;
                var pageSize = filter.pageSize ?? 10;
                var skip = pageNumber * pageSize;
                var userId = string.IsNullOrEmpty(filter.userId) ? null : filter.userId;

                var questionFilter = string.IsNullOrWhiteSpace(filter.question) ? null : $"%{filter.question.Trim()}%";
                var answerFilter = string.IsNullOrWhiteSpace(filter.answer) ? null : $"%{filter.answer.Trim()}%";
                var userFullNameFilter = string.IsNullOrWhiteSpace(filter.userFullName) ? null : $"%{filter.userFullName.Trim()}%";

                var db = await GetOpenConnectionAsync();

                // FIX: Handled dynamic casting for Score and exact day matching for CreatedDate
                const string whereClause = @"
            WHERE (@UserId IS NULL OR h.UserId = @UserId)
              AND (@Question IS NULL OR h.Question LIKE @Question)
              AND (@Answer IS NULL OR h.Answer LIKE @Answer)
              AND (@CreatedDate IS NULL OR CAST(h.CreatedDate AS DATE) = CAST(@CreatedDate AS DATE))
              AND (@UserFullName IS NULL OR (
                    (u.FirstName + ' ' + u.LastName) LIKE @UserFullName OR
                    u.UserName LIKE @UserFullName OR
                    u.Email LIKE @UserFullName OR
                    h.UserName LIKE @UserFullName
                  ))
              AND (@Score IS NULL OR (
                    -- Check if it matches an absolute numeric score column OR can be extracted out of the JSON string
                    (ISJSON(h.Answer) > 0 AND CAST(JSON_VALUE(h.Answer, '$.top_score') AS DECIMAL(18,2)) = (@Score / 100.0))
                  ))";

                string countSql = $@"
            SELECT COUNT(*)
            FROM ChatbotHistories h
            LEFT JOIN AspNetUsers u ON h.UserId = u.Id
            {whereClause};";

                string dataSql = $@"
            SELECT
                h.Id, h.SessionId, h.Question, h.Answer, h.EndSession, h.RequestUrl, 
                h.StatusCode, h.IsSuccess, h.ContentType, h.ErrorMessage, 
                h.DurationMilliseconds, h.CreatedDate, h.UserId, h.UserEmail, h.UserName,
                u.Id AS AppUserId, u.UserName AS AppUserName, u.Email AS AppUserEmail,
                u.FirstName AS AppFirstName, u.LastName AS AppLastName, u.DepartmentName AS AppDepartmentName
            FROM ChatbotHistories h
            LEFT JOIN AspNetUsers u ON h.UserId = u.Id
            {whereClause}
            ORDER BY h.CreatedDate DESC, h.Id DESC
            OFFSET @Skip ROWS FETCH NEXT @PageSize ROWS ONLY;";

                var parameters = new
                {
                    UserId = userId,
                    Question = questionFilter,
                    Answer = answerFilter,
                    CreatedDate = filter.createdDate,
                    UserFullName = userFullNameFilter,
                    Score = filter.score, // Passing numeric input filter value down cleanly
                    Skip = skip,
                    PageSize = pageSize
                };

                var totalCount = await db.ExecuteScalarAsync<int>(countSql, parameters);
                var rows = (await db.QueryAsync<ChatbotHistoryListRow>(dataSql, parameters)).ToList();
                var items = rows.Select(MapToListDto).ToList();

                ResultOutputData resultOutput = new ResultOutputData();
                return resultOutput.GenearetResultOutput(items, totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAllByPagenationAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        private static ChatbotHistoryListDto MapToListDto(ChatbotHistoryListRow row)
        {
            ChatbotHistoryUserDto? user = null;
            if (!string.IsNullOrEmpty(row.AppUserId))
            {
                var fullName = $"{row.AppFirstName} {row.AppLastName}".Trim();
                user = new ChatbotHistoryUserDto
                {
                    Id = row.AppUserId,
                    UserName = row.AppUserName,
                    Email = row.AppUserEmail,
                    FirstName = row.AppFirstName,
                    LastName = row.AppLastName,
                    FullName = string.IsNullOrEmpty(fullName) ? null : fullName,
                    DepartmentName = row.AppDepartmentName
                };
            }

            return new ChatbotHistoryListDto
            {
                Id = row.Id,
                SessionId = row.SessionId,
                Question = row.Question,
                Answer = row.Answer,
                EndSession = row.EndSession,
                RequestUrl = row.RequestUrl,
                StatusCode = row.StatusCode,
                IsSuccess = row.IsSuccess,
                ContentType = row.ContentType,
                ErrorMessage = row.ErrorMessage,
                DurationMilliseconds = row.DurationMilliseconds,
                CreatedDate = row.CreatedDate,
                UserId = row.UserId,
                UserEmail = row.UserEmail,
                UserName = row.UserName,
                User = user
            };
        }

        private sealed class ChatbotHistoryListRow
        {
            public int Id { get; set; }
            public string? SessionId { get; set; }
            public string? Question { get; set; }
            public string? Answer { get; set; }
            public bool EndSession { get; set; }
            public string? RequestUrl { get; set; }
            public int? StatusCode { get; set; }
            public bool IsSuccess { get; set; }
            public string? ContentType { get; set; }
            public string? ErrorMessage { get; set; }
            public long DurationMilliseconds { get; set; }
            public DateTime CreatedDate { get; set; }
            public string? UserId { get; set; }
            public string? UserEmail { get; set; }
            public string? UserName { get; set; }
            public string? AppUserId { get; set; }
            public string? AppUserName { get; set; }
            public string? AppUserEmail { get; set; }
            public string? AppFirstName { get; set; }
            public string? AppLastName { get; set; }
            public string? AppDepartmentName { get; set; }
        }
    }
}