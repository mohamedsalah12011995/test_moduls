﻿using Core.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System.Data;

namespace Nupco.EF.Repositories
{
    internal class MedalsRepository : BaseRepository<Medal>, IMedalsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;
        private readonly Medal_Assembler _Medal_Assembler;
        private readonly User_Assembler _User_Assembler;

        public MedalsRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _Medal_Assembler = new Medal_Assembler();
            _User_Assembler = new User_Assembler();

            _logger = logger;
            _context = context;
        }

        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var medal = await FindAsync(f => f.Id == id);
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                medal.IsActive = activate;
                medal.ActivatedDate = DateTime.Now;

                Update(medal);
                await SaveChangesAsync();

                return ResultOutputData.GenearetResultOutputSuccess();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error changing activation state for medal {Id}", id);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> AddNewAsync(MedalObjDto entity)
        {
            try
            {
                var isCodeExists = await _context.Medals
                    .AsNoTracking()
                    .AnyAsync(m => m.Code == entity.Code && m.IsDeleted==false);

                if (isCodeExists)
                {
                    return ResultOutputData.GenerateResultOutputFailure("كود الوسام مستخدم مسبقاً، يرجى إدخال كود آخر.", "The badge code is already in use, please enter another code");
                }

                entity.IsActive = true;
                entity.IsDeleted = false;
                entity.CreatedDate = DateTime.Now; 

                if (!string.IsNullOrEmpty(entity.OriginalPicBase64) && !Strings.CheckStringNullOrEmptyOrWhiteSpaceOrZero(entity.OriginalPicBase64))
                {
                    entity.OriginalPic = Images.SaveSingleImageOnServer(entity.OriginalPicBase64, 1024, entity.pathToSave, false, 0, entity.pathToSave);
                }

                var model = _Medal_Assembler.WriteDal(entity);
                var addedEntity = await AddAsync(model);
                await _context.SaveChangesAsync();

                return new ResultOutputData().GenearetResultOutput(addedEntity, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding new medal");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> DeleteEntity(int id, string userId)
        {
            try
            {
                var medal = await FindAsync(f => f.Id == id);
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                medal.IsDeleted = true;
                medal.DeletedBy = userId;
                medal.DeletedDate = DateTime.Now;

                Update(medal);
                await SaveChangesAsync();

                return ResultOutputData.GenearetResultOutputSuccess();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error soft deleting medal {Id}", id);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FiltersBy filter)
        {
            try
            {
                string[] includes = { "CreatedByUser", "UpdatedByUser", "DeletedByUser", "ActivatedByUser", "MedalUsers" ,"MedalCategory"};
                var spec = Specification<Medal>.All.And(new MedalSpecification(filter));
                var medals = await FindAllAsync(
                    spec.ToExpression(),
                    (int)filter.pageNumber * (int)filter.pageSize,
                    (int)filter.pageSize,
                    includes);

                var medalsDto = _Medal_Assembler.WriteListDto(medals);
                var totalCount = Count(i => i.IsDeleted == false);

                return new ResultOutputData().GenearetResultOutput(medalsDto, totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching paginated medals");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {
                string[] includes = { "CreatedByUser", "UpdatedByUser", "DeletedByUser", "ActivatedByUser" , "MedalCategory" };

                var entities = await FindAllAsync(i => i.IsDeleted == false && i.IsActive==true, includes);
                var entitiesDto = _Medal_Assembler.WriteListDto(entities);
                var totalCount = await CountAsync(i => i.IsDeleted == false);

                return new ResultOutputData().GenearetResultOutput(entitiesDto, totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching all medals");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                string[] includes = { "CreatedByUser", "UpdatedByUser", "DeletedByUser", "ActivatedByUser", "MedalCategory" };

                var medal = await FindAsync(f => f.Id == id && f.IsDeleted == false, includes);
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                var entityDto = _Medal_Assembler.WriteDto(medal);
                var query = _context.MedalUsers
                .AsNoTracking()
                .Where(mu => mu.MedalId == id
                 && mu.Medal.IsDeleted == false
                 && mu.Medal.IsActive == true
                 && mu.IsRevoked != true);
                entityDto.TotalRecipientsCount = query.Count();

                return new ResultOutputData().GenearetResultOutput(entityDto, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching medal by id {Id}", id);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> UpdateEntity(MedalObjDto entity)
        {
            try
            {
                var medal = await FindAsync(i => i.Id == entity.Id);
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                if (!string.IsNullOrEmpty(entity.OriginalPicBase64) && !Strings.CheckStringNullOrEmptyOrWhiteSpaceOrZero(entity.OriginalPicBase64))
                {
                    medal.OriginalPic = Images.SaveSingleImageOnServer(entity.OriginalPicBase64, 1024, entity.pathToSave, false, 0, entity.pathToSave);
                }

                medal.TitleAr = entity.TitleAr;
                medal.TitleEn = entity.TitleEn;
                medal.DescriptionAr = entity.DescriptionAr;
                medal.DescriptionEn = entity.DescriptionEn;
                medal.Code = entity.Code;
                medal.PeriodInDays = entity.PeriodInDays;
                medal.UpdatedBy = entity.UpdatedBy;
                medal.UpdatedDate = DateTime.Now;
                medal.EligibilityCriteriaAr = entity.EligibilityCriteriaAr;
                medal.EligibilityCriteriaEn = entity.EligibilityCriteriaEn;
                medal.MedalCategoryId = entity.MedalCategoryId;

                var updatedModel = Update(medal);
                await SaveChangesAsync();

                var mappedDto = _Medal_Assembler.WriteDto(updatedModel);
                return new ResultOutputData().GenearetResultOutput(mappedDto, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating medal {Id}", entity.Id);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public Task<OperationOutput> UpdateEntityAsync(MedalObjDto t, object key) => throw new NotImplementedException();
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<MedalObjDto> entities) => throw new NotImplementedException();
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<MedalObjDto> entities) => throw new NotImplementedException();

        public async Task<OperationOutput> CreateMedalAsync(Medal medal)
        {
            try
            {
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                medal.CreatedDate = DateTime.Now;
                medal.IsActive = true;
                medal.IsDeleted = false;

                await _context.Medals.AddAsync(medal);
                await _context.SaveChangesAsync();

                return new ResultOutputData().GenearetResultOutput(medal, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing CreateMedalAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> UpdateMedalAsync(Medal medal)
        {
            try
            {
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                var entity = await _context.Medals.FindAsync(medal.Id);
                if (entity == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                entity.TitleAr = medal.TitleAr;
                entity.TitleEn = medal.TitleEn;
                entity.DescriptionAr = medal.DescriptionAr;
                entity.DescriptionEn = medal.DescriptionEn;
                entity.Code = medal.Code;
                entity.PeriodInDays = medal.PeriodInDays;
                entity.OriginalPic = medal.OriginalPic;
                entity.UpdatedBy = medal.UpdatedBy;
                entity.UpdatedDate = DateTime.Now;
                medal.EligibilityCriteriaAr = entity.EligibilityCriteriaAr;
                medal.EligibilityCriteriaEn = entity.EligibilityCriteriaEn;
                medal.MedalCategoryId = entity.MedalCategoryId;

                _context.Medals.Update(entity);
                await _context.SaveChangesAsync();

                return new ResultOutputData().GenearetResultOutput(entity, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing UpdateMedalAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetAllMedalsAsync(bool includeInactive)
        {
            try
            {
                var query = _context.Medals.Where(m => m.IsDeleted == false);
                if (!includeInactive)
                {
                    query = query.Where(m => m.IsActive == true);
                }

                var list = await query.ToListAsync();
                return new ResultOutputData().GenearetResultOutput(list, list.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetAllMedalsAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetMedalDetailsByIdWithUsers(int medalId, string? searchTerm = null, int pageNumber = 1, int pageSize = 10)
        {
            try
            {
                string[] includes = { "CreatedByUser", "UpdatedByUser", "DeletedByUser", "ActivatedByUser", "MedalCategory" };
                var medal = await FindAsync(f => f.Id == medalId && f.IsDeleted == false && f.IsActive == true, includes);
                if (medal == null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                var medalDto = _Medal_Assembler.WriteDto(medal);

                var query = _context.MedalUsers
                    .AsNoTracking()
                    .Where(mu => mu.MedalId == medalId
                                 && mu.Medal.IsDeleted == false
                                 && mu.IsRevoked != true);

                medalDto.TotalRecipientsCount = await query.CountAsync();

                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    var term = searchTerm.Trim();
                    query = query.Where(mu =>
                        mu.AssignedByUser != null && (
                            mu.AssignedByUser.UserName.Contains(term) ||
                            (mu.AssignedByUser.FirstName + " " + mu.AssignedByUser.LastName).Contains(term)
                        ));
                }

                var totalRecipientsCount = await query
                    .Select(x => x.AssignedBy)
                    .Distinct()
                    .CountAsync();

                if (totalRecipientsCount == 0)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                int skip = Math.Max(0, (pageNumber - 1) * pageSize);

                var pagedData = await query
                    .GroupBy(g => g.AssignedBy)
                    .Select(s => new
                    {
                        UserId = s.Key,
                        UserName = s.Select(x => x.AssignedByUser.UserName).FirstOrDefault(),
                        FirstName = s.Select(x => x.AssignedByUser.FirstName).FirstOrDefault(),
                        LastName = s.Select(x => x.AssignedByUser.LastName).FirstOrDefault(),
                        OriginalPic = s.Select(x => x.AssignedByUser.OriginalPic).FirstOrDefault(),
                        ExpiryDate = s.Max(m => m.ExpiryDate),
                        MedalCount = s.Count()
                    })
                    .OrderByDescending(o => o.MedalCount)
                    .ThenByDescending(o => o.ExpiryDate)
                    .Skip(skip)
                    .Take(pageSize)
                    .ToListAsync();

                int startingRank = (pageNumber - 1) * pageSize;

                var list = pagedData
                    .Select((s, index) => new
                    {
                        userId = s.UserId,
                        userName = s.UserName ?? string.Empty,
                        fullName = (s.FirstName + " " + s.LastName).Trim(),
                        ExpiryDate = s.ExpiryDate,
                        medalCount = s.MedalCount,
                        OriginalPic = s.OriginalPic,
                        isGoldMedal = (startingRank + index) < 3
                    })
                    .ToList();

                var pagedResult = new
                {
                    Items = list,
                    Medal = medalDto,
                    TotalCount = totalRecipientsCount,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    TotalPages = (int)Math.Ceiling(totalRecipientsCount / (double)pageSize)
                };

                return new ResultOutputData().GenearetResultOutput(pagedResult, totalRecipientsCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetMedalDetailsByIdWithUsers for MedalId: {MedalId}", medalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> GetAllUsersWithMedalId(int medalId, string? searchTerm = null, int pageNumber = 1, int pageSize = 10)
        {
            try
            {
                string[] includes = { "CreatedByUser", "UpdatedByUser", "DeletedByUser", "ActivatedByUser", "MedalCategory" };
                var medal = await FindAsync(f => f.Id == medalId && f.IsDeleted == false && f.IsActive == true, includes);
                if (medal == null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                var medalDto = _Medal_Assembler.WriteDto(medal);

                var query = _context.MedalUsers
                    .Include(i=> i.AssignedByUser)
                    .AsNoTracking()
                    .Where(mu => mu.MedalId == medalId
                                 && mu.Medal.IsDeleted == false
                                 && mu.IsRevoked == false);

                if (!string.IsNullOrWhiteSpace(searchTerm))
                {
                    var term = searchTerm.Trim().ToLower();
                    query = query.Where(mu =>
                        mu.AssignedByUser.UserName.ToLower().Contains(term) ||
                        (mu.AssignedByUser.FirstName + " " + mu.AssignedByUser.LastName).ToLower().Contains(term));
                }

                var baseQuery = query
                    .GroupBy(g => new
                    {
                        userId = g.AssignedBy, 
                        userName = g.AssignedByUser.UserName,
                        firstName = g.AssignedByUser.FirstName,
                        lastName = g.AssignedByUser.LastName,
                        orignalPic=g.AssignedByUser.OriginalPic
                    })
                    .Select(s => new
                    {
                        s.Key.userId,
                        s.Key.userName,
                        fullName = (s.Key.firstName + " " + s.Key.lastName).Trim(),
                        OriginalPic = s.FirstOrDefault().AssignedByUser.OriginalPic,
                        ExpiryDate = s.Max(m => m.ExpiryDate),
                        medalCount = s.Count()
                    })
            .OrderByDescending(o => o.medalCount)
            .ThenByDescending(o => o.ExpiryDate)
            .ThenBy(o => o.userName);

                var totalCount = await baseQuery.CountAsync();

                int skip = (pageNumber - 1) * pageSize;
                var pagedData = await baseQuery
                    .Skip(skip < 0 ? 0 : skip)
                    .Take(pageSize)
                    .ToListAsync();

                int startingRank = (pageNumber - 1) * pageSize;

                var list = pagedData
                    .Select((s, index) => new
                    {
                        s.userId,
                        s.userName,
                        s.fullName,
                        s.ExpiryDate,
                        s.medalCount,
                        s.OriginalPic,
                        isGoldMedal = (startingRank + index) < 3 // Top 3 Overall
                    })
                    .ToList();

                // 7. Result Assembly
                var pagedResult = new
                {
                    Items = list,
                    Medal = medalDto,
                    TotalCount = totalCount,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize)
                };
                totalCount = medalDto is not null && !list.Any() ? 1 : totalCount;

                return new ResultOutputData().GenearetResultOutput(pagedResult, totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetAllUsersWithMedalId for MedalId: {MedalId}", medalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> GetMedalAwardHistoryAsync(int medalId, bool? isRevoked = null, int pageNumber = 1, int pageSize = 10)
        {
            try
            {
                var baseQuery = _context.MedalUsers
                    .Where(mu => mu.MedalId == medalId && mu.Medal.IsDeleted == false && mu.Medal.IsActive == true);

                if (isRevoked.HasValue)
                {
                    baseQuery = baseQuery.Where(mu => mu.IsRevoked == isRevoked.Value);
                }

                int totalCount = await baseQuery
                    .Select(mu => mu.AssignedBy)
                    .Distinct()
                    .CountAsync();

                if (totalCount == 0)
                {
                    return new ResultOutputData().GenearetResultOutput(new List<object>(), 0);
                }

                var pagedGroupedInfo = await baseQuery
                    .GroupBy(mu => mu.AssignedBy)
                    .Select(group => new
                    {
                        AssignedBy = group.Key,
                        MaxCreatedDate = group.Max(mu => mu.CreatedDate),
                        LatestId = group.OrderByDescending(mu => mu.CreatedDate).Select(mu => mu.Id).FirstOrDefault(),
                        AssignmentCount = group.Count()
                    })
                    .OrderByDescending(g => g.MaxCreatedDate)
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                var latestIds = pagedGroupedInfo.Select(g => g.LatestId).ToList();

                var detailedRecords = await _context.MedalUsers
                    .Include(mu => mu.Medal)
                    .Include(mu => mu.AssignedByUser)
                    .Include(mu => mu.AwardedByUser)
                    .Where(mu => latestIds.Contains(mu.Id))
                    .ToListAsync();

                var history = pagedGroupedInfo
                    .Select(g =>
                    {
                        var mu = detailedRecords.FirstOrDefault(r => r.Id == g.LatestId);
                        return new
                        {
                            Id = g.LatestId,
                            MedalId = medalId,
                            AssignmentCount = g.AssignmentCount,
                            MedalTitleAr = mu?.Medal?.TitleAr ?? string.Empty,
                            MedalTitleEn = mu?.Medal?.TitleEn ?? string.Empty,
                            AssignedByName = mu?.AssignedByUser != null ? $"{mu.AssignedByUser.FirstName} {mu.AssignedByUser.LastName}".Trim() : string.Empty,
                            AwardedByName = mu?.AwardedByUser != null ? $"{mu.AwardedByUser.FirstName} {mu.AwardedByUser.LastName}".Trim() : string.Empty,
                            Message = mu?.Message ?? string.Empty,
                            IsRevoked = mu?.IsRevoked ?? false,
                            CreatedDate = g.MaxCreatedDate
                        };
                    })
                    .OrderByDescending(h => h.CreatedDate)
                    .ToList();

                return new ResultOutputData().GenearetResultOutput(history, totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetMedalAwardHistoryAsync for MedalId {Id}", medalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> RevokeMedalsInBulkAsync(BulkAwardItemDto bulkAwardItem)
        {
            if (bulkAwardItem.assignByUsers == null || !bulkAwardItem.assignByUsers.Any())
                return ResultOutputData.GenearetResultOutputNoDataReturned();

            if (string.IsNullOrWhiteSpace(bulkAwardItem.Message))
                return ResultOutputData.GenerateResultOutputFailure("Reason is required.");

            var resultSummary = new BulkRevokeResultDto();

            var cleanUserList = bulkAwardItem.assignByUsers
                .Where(u => !string.IsNullOrWhiteSpace(u))
                .Select(u => u.Trim().Replace("@nupco.com", "", StringComparison.OrdinalIgnoreCase))
                .Distinct()
                .ToList();

            var existingUsers = await _context.Users
                .Where(u => cleanUserList.Contains(u.Id) || cleanUserList.Contains(u.UserName))
                .Select(u => cleanUserList.Contains(u.Id) ? u.Id : u.UserName)
                .ToListAsync();

            resultSummary.NotFoundUsers = cleanUserList.Except(existingUsers, StringComparer.OrdinalIgnoreCase).ToList();
            resultSummary.FoundUsers = existingUsers;

            if (!resultSummary.FoundUsers.Any())
            {
                return new ResultOutputData().GenearetResultOutput(resultSummary, 0);
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var activeMedalRecords = await _context.MedalUsers
                    .Include(i => i.Medal)
                    .Where(f => f.Medal.IsDeleted == false &&
                                f.MedalId == bulkAwardItem.MedalId &&
                                resultSummary.FoundUsers.Contains(f.AssignedBy) &&
                                f.IsRevoked == false)
                    .ToListAsync();

                var currentUtc = DateTime.Now;

                foreach (var record in activeMedalRecords)
                {
                    record.IsRevoked = true;
                    record.RevokedBy = bulkAwardItem.HrUserId;
                    record.RevokedDate = currentUtc;
                    record.RevokeReason = bulkAwardItem.Message.Trim();
                    record.ExpiryDate = currentUtc;
                }

                if (activeMedalRecords.Any())
                {
                    _context.MedalUsers.UpdateRange(activeMedalRecords);
                    await _context.SaveChangesAsync();
                }

                await transaction.CommitAsync();

                return new ResultOutputData().GenearetResultOutput(resultSummary, resultSummary.FoundUsers.Count);
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Error executing RevokeMedalsInBulkAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> RevokeMedalAsync(int medalId , string assignBy, string mandatoryReason, string hrUserId)
        {

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var record = await _context.MedalUsers.Include(i => i.Medal)
                    .FirstOrDefaultAsync(f => f.Medal.IsDeleted == false && f.AssignedBy == assignBy && f.MedalId == medalId && f.IsRevoked == false);
                if (record == null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                if (record.IsRevoked)
                    return ResultOutputData.GenerateResultOutputFailure("This medal has already been revoked.");

                var currentUtc = DateTime.Now;

                record.IsRevoked = true;
                record.RevokedBy = hrUserId;
                record.RevokedDate = currentUtc;
                record.RevokeReason = mandatoryReason;
                record.ExpiryDate = currentUtc; 

                _context.MedalUsers.Update(record);
                await SaveChangesAsync();
                await transaction.CommitAsync();

                return ResultOutputData.GenearetResultOutputSuccess();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Error executing RevokeMedalAsync {Id}", assignBy);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetEmployeeMedalsAsync(string employeeId)
        {
            try
            {
                if (string.IsNullOrEmpty(employeeId)) return ResultOutputData.GenearetResultOutputNoDataReturned();

                var list = await _context.MedalUsers
                    .Include(i => i.Medal)
                    .Include(i => i.AssignedByUser)
                    .Include(i => i.AwardedByUser)
                    .Include(i => i.RevokedByUser)
                    .Where(mu => mu.AssignedBy == employeeId && mu.Medal.IsDeleted == false && mu.Medal.IsActive == true && mu.IsRevoked == false)
                    .OrderByDescending(mu => mu.CreatedDate)
                    .ToListAsync();

                var data = _Medal_Assembler.WriteListDto(list);

                return new ResultOutputData().GenearetResultOutput(data, data.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetEmployeeMedalsAsync for {User}", employeeId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> GetEmployeeMedalCountAsync(string employeeId)
        {
            try
            {
                if (string.IsNullOrEmpty(employeeId)) return ResultOutputData.GenearetResultOutputNoDataReturned();

                var count = await _context.MedalUsers.Include(i=> i.Medal)
                    .CountAsync(mu => mu.AssignedBy == employeeId
                                   && mu.Medal.IsDeleted == false
                                   && mu.IsRevoked == false
                                   && mu.Medal.IsDeleted == false
                                   && mu.Medal.IsActive == true
                                   && mu.IsRevoked == false
                                   && (mu.ExpiryDate == null || mu.ExpiryDate > DateTime.Now));

                return new ResultOutputData().GenearetResultOutput(count, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetEmployeeMedalCountAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetMedalDetailsAsync(int medalId)
        {
            try
            {
                var medal = await _context.Medals.Include(i=> i.MedalCategory).FirstOrDefaultAsync(m => m.Id == medalId && m.IsDeleted == false);
                if (medal == null) return ResultOutputData.GenearetResultOutputNoDataReturned();

                var recipientsCount = await _context.MedalUsers.CountAsync(mu => mu.MedalId == medalId && mu.IsRevoked == false && (mu.ExpiryDate == null || mu.ExpiryDate > DateTime.Now));
                var details = _Medal_Assembler.WriteDto(medal);

                return new ResultOutputData().GenearetResultOutput(details, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetMedalDetailsAsync {Id}", medalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }



        public async Task<OperationOutput> GetTop10LeaderboardAsync(int? medalId = null)
        {
            try
            {
                var userMedalsQuery = _context.MedalUsers
                    .Include(i => i.Medal)
                    .Include(i => i.AssignedByUser)
                    .Where(mu => mu.Medal.IsDeleted == false 
                                 &&mu.Medal.IsActive == true
                                 && mu.IsRevoked == false
                                 && (mu.ExpiryDate == null || mu.ExpiryDate > DateTime.Now)
                                 && (!medalId.HasValue || mu.MedalId == medalId.Value))
                    .GroupBy(mu => new
                    {
                        mu.AssignedBy,
                        mu.AssignedByUser.FirstName,
                        mu.AssignedByUser.LastName,
                        mu.AssignedByUser.PositionName,
                        mu.AssignedByUser.OriginalPic
                    })
                    .Select(g => new LeaderboardEntryDto
                    {
                        MedalTitleAr = g.Select(x => x.Medal.TitleAr).FirstOrDefault() ?? string.Empty,
                        MedalTitleEn = g.Select(x => x.Medal.TitleEn).FirstOrDefault() ?? string.Empty,
                        OriginalPic = g.FirstOrDefault().AssignedByUser.OriginalPic?? string.Empty,
                        UserId = g.Key.AssignedBy,
                        FullName = ((g.Key.FirstName ?? "") + " " + (g.Key.LastName ?? "")).Trim(),
                        Position = g.Key.PositionName ?? string.Empty,
                        MedalsCount = g.Count()
                    });

                var top10DistinctCounts = await userMedalsQuery
                    .Select(x => x.MedalsCount)
                    .OrderByDescending(c => c)
                    .Take(10)
                    .ToListAsync();

                var top10Leaderboard = await userMedalsQuery
                    .Where(x => top10DistinctCounts.Contains(x.MedalsCount))
                    .OrderByDescending(x => x.MedalsCount)
                    .ThenBy(x => x.FullName)
                    .Take(10)
                    //.Distinct()
                    .ToListAsync();

                return new ResultOutputData().GenearetResultOutput(top10Leaderboard, top10Leaderboard.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetTop10LeaderboardAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetTop100LeaderboardAsync(int? medalId = null)
        {
            try
            {
                var baseQuery = _context.MedalUsers
                    .Include(i => i.Medal)
                    .Where(mu => mu.Medal.IsDeleted == false
                                 && mu.Medal.IsActive == true
                                 && mu.IsRevoked == false
                                 && (mu.ExpiryDate == null || mu.ExpiryDate > DateTime.Now)
                                 && (!medalId.HasValue || mu.MedalId == medalId.Value))
                    .GroupBy(mu => new
                    {
                        mu.AssignedBy,
                        mu.AssignedByUser.FirstName,
                        mu.AssignedByUser.LastName,
                        mu.AssignedByUser.PositionName,
                        mu.AssignedByUser.OriginalPic
                    })
                    .Select(g => new LeaderboardEntryDto
                    {
                        MedalTitleAr = g.FirstOrDefault().Medal.TitleAr,
                        MedalTitleEn = g.FirstOrDefault().Medal.TitleEn,
                        OriginalPic = g.FirstOrDefault().AssignedByUser.OriginalPic,
                        UserId = g.Key.AssignedBy,
                        FullName = (g.Key.FirstName + " " + g.Key.LastName).Trim(),
                        Position = g.Key.PositionName,
                        MedalsCount = g.Count()
                    })
                    .OrderByDescending(x => x.MedalsCount);

                var leaderboard = await baseQuery
                     .OrderByDescending(x => x.MedalsCount)
                    .ThenBy(x => x.FullName)
                    .Skip(10)
                    .Take(100)
                    //.Distinct()
                    .ToListAsync();

                return new ResultOutputData().GenearetResultOutput(leaderboard, leaderboard.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing GetTop100LeaderboardAsync");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> AssignUserMedal(MedalUserObjDto medalUserObj)
        {
            if (medalUserObj == null || medalUserObj.UsersIds == null || !medalUserObj.UsersIds.Any())
            {
                return ResultOutputData.GenearetResultOutputNoDataReturned();
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var medal = await FindAsync(x => x.Id == medalUserObj.MedalId && x.IsActive == true && x.IsDeleted == false);
                if (medal == null)
                {
                    await transaction.RollbackAsync();
                    return ResultOutputData.GenerateResultOutputFailure("الوسام غير موجود أو غير مفعل.", "Medal is not found or inactive.");
                }

                var nowUtc = DateTime.UtcNow;

                DateTime? expiryDate = medal.PeriodInDays.HasValue && medal.PeriodInDays.Value > 0
                    ? nowUtc.AddDays(medal.PeriodInDays.Value)
                    : null;

                var uniqueUserIds = medalUserObj.UsersIds
                    .Where(id => !string.IsNullOrWhiteSpace(id))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();

                if (!uniqueUserIds.Any())
                {
                    await transaction.RollbackAsync();
                    return ResultOutputData.GenearetResultOutputNoDataReturned();
                }

                var existingUserIds = (await _context.MedalUsers
                    .AsNoTracking()
                    .Where(mu => mu.MedalId == medalUserObj.MedalId
                                 && uniqueUserIds.Contains(mu.AssignedBy)
                                 && mu.IsRevoked == false
                                 && (mu.ExpiryDate == null || mu.ExpiryDate > nowUtc))
                    .Select(mu => mu.AssignedBy) // 
                    .ToListAsync())
                    .ToHashSet(StringComparer.OrdinalIgnoreCase);

                var usersToAssign = uniqueUserIds.Where(userId => !existingUserIds.Contains(userId)).ToList();

                if (!usersToAssign.Any())
                {
                    await transaction.RollbackAsync();
                    return ResultOutputData.GenerateResultOutputFailure("جميع المستخدمين المحددين لديهم هذا الوسام نشط بالفعل.", "All specified users already have this active medal.");
                }

                var cleanMessage = medalUserObj.Message?.Trim();

                var medalUsers = usersToAssign.Select(userId => new MedalUser
                {
                    MedalId = medalUserObj.MedalId,
                    AssignedBy = userId,
                    AwardedBy = medalUserObj.AwardedBy,
                    Message = cleanMessage,
                    ExpiryDate = expiryDate,
                    CreatedDate = nowUtc,
                    IsRevoked = false,
                    SendNotification = medalUserObj.SendNotification,
                    SendEmail = medalUserObj.SendEmail
                }).ToList();

                await _context.MedalUsers.AddRangeAsync(medalUsers);
                await SaveChangesAsync();

                await transaction.CommitAsync();

                return new ResultOutputData().GenearetResultOutput(usersToAssign, usersToAssign.Count);
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Error assigning medal {MedalId} to users.", medalUserObj?.MedalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> AssignMedalsInBulkAsync(BulkAwardItemDto bulkAwardItem)
        {
            if (bulkAwardItem.assignByUsers == null || !bulkAwardItem.assignByUsers.Any())
                return ResultOutputData.GenearetResultOutputNoDataReturned();

            var resultSummary = new BulkAwardResultDto();

            var cleanInputList = bulkAwardItem.assignByUsers
                .Where(u => !string.IsNullOrWhiteSpace(u))
                .Select(u => u.Trim().Replace("@nupco.com", "", StringComparison.OrdinalIgnoreCase))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (!cleanInputList.Any())
                return ResultOutputData.GenearetResultOutputNoDataReturned();

            var dbUserMatchPool = await _context.Users
                .Where(u => cleanInputList.Contains(u.Id) || cleanInputList.Contains(u.UserName))
                .Select(u => new { u.Id, u.UserName })
                .ToListAsync();

            var foundUserIds = new HashSet<string>(dbUserMatchPool.Select(u => u.Id), StringComparer.OrdinalIgnoreCase);
            var foundUserNames = new HashSet<string>(dbUserMatchPool.Select(u => u.UserName), StringComparer.OrdinalIgnoreCase);

            resultSummary.NotFoundUsers = cleanInputList
                .Where(input => !foundUserIds.Contains(input) && !foundUserNames.Contains(input))
                .ToList();

            if (!dbUserMatchPool.Any())
            {
                resultSummary.FoundUsers = new List<string>();
                return new ResultOutputData().GenearetResultOutput(resultSummary, 0);
            }

            resultSummary.FoundUsers = dbUserMatchPool.Select(u => u.UserName).Distinct().ToList();

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var medal = await FindAsync(x => x.Id == bulkAwardItem.MedalId && x.IsActive == true && x.IsDeleted == false);
                if (medal == null)
                {
                    await transaction.RollbackAsync();
                    return ResultOutputData.GenearetResultOutputNoDataReturned();
                }

                var nowUtc = DateTime.UtcNow;

                DateTime? expiryDate = bulkAwardItem.ExpiryDate.HasValue
                    ? bulkAwardItem.ExpiryDate
                    : (medal.PeriodInDays.HasValue && medal.PeriodInDays.Value > 0
                        ? nowUtc.AddDays(medal.PeriodInDays.Value)
                        : null);

                var matchedUserIds = dbUserMatchPool.Select(u => u.Id).Distinct().ToList();

                var usersWithActiveMedal = await _context.MedalUsers
                    .Where(mu => mu.MedalId == bulkAwardItem.MedalId
                                 && matchedUserIds.Contains(mu.AssignedBy)
                                 && mu.IsRevoked == false
                                 && (mu.ExpiryDate == null || mu.ExpiryDate > nowUtc))
                    .Select(mu => mu.AssignedBy)
                    .ToListAsync();

                var existingActiveUserSet = new HashSet<string>(usersWithActiveMedal, StringComparer.OrdinalIgnoreCase);

                var usersToAssign = matchedUserIds.Where(id => !existingActiveUserSet.Contains(id)).ToList();

                if (!usersToAssign.Any())
                {
                    await transaction.RollbackAsync();
                    return ResultOutputData.GenerateResultOutputFailure(
                        "جميع الموظفين المحددين تم منحهم هذا الوسام من قبل وساري المفعول.",
                        "All matching users are already assigned this active medal."
                    );
                }

                var cleanMessage = bulkAwardItem.Message.Trim();

                var medalUsers = usersToAssign.Select(userId => new MedalUser
                {
                    MedalId = bulkAwardItem.MedalId,
                    AssignedBy = userId,                 
                    AwardedBy = bulkAwardItem.HrUserId,  
                    Message = cleanMessage,
                    ExpiryDate = expiryDate,
                    CreatedDate = nowUtc,
                    IsRevoked = false,
                    SendNotification = bulkAwardItem.SendNotification,
                    SendEmail = bulkAwardItem.SendEmail
                }).ToList();

                await _context.MedalUsers.AddRangeAsync(medalUsers);
                await SaveChangesAsync();

                resultSummary.InsertedUserIds.AddRange(usersToAssign);

                await transaction.CommitAsync();
                return new ResultOutputData().GenearetResultOutput(resultSummary, usersToAssign.Count);
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Error executing AssignMedalsInBulkAsync for Medal {MedalId}", bulkAwardItem.MedalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> GetUsersNotAssignedMedalAsync(int medalId)
        {
            try
            {
                var unassignedUsers = await _context.Users
                    .AsNoTracking()
                    .Where(u => !u.IsDeleted && !_context.MedalUsers.Any(m => m.MedalId == medalId && m.AssignedBy == u.Id && m.IsRevoked==false))
                    .ToListAsync();

                var usersDto = _User_Assembler.WriteListDto(unassignedUsers);

                return new ResultOutputData().GenearetResultOutput(usersDto, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching users not assigned to medal {MedalId}", medalId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
    }
}