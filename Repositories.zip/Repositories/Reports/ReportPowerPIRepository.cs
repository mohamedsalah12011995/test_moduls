﻿using Core.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using YourProject.DAL.Models.Buses;
using Location = Nupco.DAL.Models.Location;

namespace Nupco.EF.Repositories
{
    internal class ReportPowerBIRepository : BaseRepository<ReportPowerBI>, IReportPowerBIRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;
        private readonly ReportPowerBI_Assembler _ReportPowerBI_Assembler;

        private string[] stringArray = { "Category", "CreatedByUsers", "UpdatedByUsers" };


        public ReportPowerBIRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _ReportPowerBI_Assembler = new ReportPowerBI_Assembler();
            _logger = logger;
            _context = context;

        }


        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(ReportPowerBIObjDto entity)
        {
            try
            {
                if (!String.IsNullOrEmpty(entity.OriginalPicBase64))
                {
                    entity.OriginalPic = !Strings.CheckStringNullOrEmptyOrWhiteSpaceOrZero(entity.OriginalPicBase64) ?
                            Images.SaveSingleImageOnServer(entity.OriginalPicBase64, 1024, entity.pathToSave, false, 0, entity.pathToSave) : entity.OriginalPic;
                }

                var _model = _ReportPowerBI_Assembler.WriteDal(entity);
                var _entity = await AddAsync(_model);
                await _context.SaveChangesAsync();


                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(_entity, 1);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> DeleteEntity(int id, string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDeleted = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FilterByReportPowerBI _filter)
        {
            try
            {
                var spec = Specification<ReportPowerBI>.All.And(new ReportPowerBIpecification(_filter));

                var entites = await _context.ReportPowerBI
                    .Where(spec.ToExpression())
                    .Where(i => !i.IsDeleted)
                    .Include(i => i.Category)
                    .OrderByDescending(o => o.Id)
                    .Skip((int)_filter.pageNumber * (int)_filter.pageSize).Take((int)_filter.pageSize)
                     .AsNoTrackingWithIdentityResolution().ToListAsync();

                var ReportPowerBI = entites.Where(i => i.IsDeleted == false).ToList();
                var _ReportPowerBI = _ReportPowerBI_Assembler.WriteListDto(ReportPowerBI);
                var counts = await CountAsync(i => i.IsDeleted == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_ReportPowerBI, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false, stringArray);
                var _entities = _ReportPowerBI_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var ReportPowerBI = await GetByIdAsync(id);
                if (ReportPowerBI != null)
                {
                    var _ReportPowerBI = _ReportPowerBI_Assembler.WriteDto(ReportPowerBI);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_ReportPowerBI, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> UpdateEntity(ReportPowerBIObjDto entity)
        {
            try
            {

                var _entity = await FindAsync(i => i.Id == entity.Id);
                if (_entity is not null)
                {
                    if (!String.IsNullOrEmpty(entity.OriginalPicBase64))
                    {
                        _entity.OriginalPic = !Strings.CheckStringNullOrEmptyOrWhiteSpaceOrZero(entity.OriginalPicBase64) ?
                                Images.SaveSingleImageOnServer(entity.OriginalPicBase64, 1024, entity.pathToSave, false, 0, entity.pathToSave) : _entity.OriginalPic;
                    }
                    _entity.IsActive = true;
                    _entity.IsDeleted = false;
                    _entity.NameAr = entity.NameAr;
                    _entity.NameEn = entity.NameEn;
                    _entity.DescriptionAr = entity.DescriptionAr;
                    _entity.DescriptionEn = entity.DescriptionEn;
                    _entity.URL = entity.URL;
                    _entity.CategoryId = entity.CategoryId;
                    _entity.UpdatedBy = entity.UpdatedBy;
                    _entity.UpdatedDate  = DateTime.Now;
                   
                    var _model = Update(_entity);
                    await SaveChangesAsync();

                    ResultOutputData resultOutput = new ResultOutputData();
                    var _result = resultOutput.GenearetResultOutput(_model, 1);
                    return _result;
                }

                else
                {
                    var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return Result;
                }

            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }


        public async Task<OperationOutput> GetRecordByCategoryId(int categoryId)
        {
            try
            {
                var categories = await _context.ReportPowerBI.Where(i=> i.CategoryId==categoryId)
                     .AsNoTracking()
                     .Select(s => new
                     {
                         CategoryId = s.Category.Id,
                         CategoryParentId = s.Category.ParentCategoryId,
                         CategoryNameAr = s.Category.NameAr,
                         CategoryNameEn = s.Category.NameEn,

                         ReportId = s.Id,
                         ReportNameAr = s.NameAr,
                         ReportNameEn = s.NameEn,
                         ReportUrl = s.URL,
                         OriginalPic = s.OriginalPic,

                         IsSubCategory = s.Category.ParentCategoryId.HasValue
                     })
                     .ToListAsync();

                if (categories.Count > 0)
                {
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(categories, categories.Count());
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }
        public async Task<OperationOutput> GetCategoriesFromReport()
        {
            try
            {
                var categories = await _context.ReportPowerBI
     .AsNoTracking()
     .Select(s => new 
     {
         CategoryId = s.Category.Id,
         CategoryParentId = s.Category.ParentCategoryId,
         CategoryNameAr = s.Category.NameAr,
         CategoryNameEn = s.Category.NameEn,

         ReportId = s.Id,
         ReportNameAr = s.NameAr,
         ReportNameEn = s.NameEn,
         ReportUrl = s.URL,
         OriginalPic = s.OriginalPic,

         IsSubCategory = s.Category.ParentCategoryId.HasValue
     })
     .ToListAsync();

                if (categories.Count > 0)
                {
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(categories, categories.Count());
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        private static void BuildCategoryHierarchy(
    int categoryId,
    Dictionary<int, CategoryNode> categories,
    List<CategoryHierarchyDto> result,
    string path,
    int level)
        {
            if (!categories.ContainsKey(categoryId))
                return;

            var category = categories[categoryId];
            var currentPath = string.IsNullOrEmpty(path)
                ? category.Id.ToString()
                : $"{path}/{category.Id}";

            result.Add(new CategoryHierarchyDto
            {
                Id = category.Id,
                ParentCategoryId = category.ParentCategoryId,
                NameAr = category.NameAr,
                NameEn = category.NameEn,
                Level = level,
                Path = currentPath
            });

            var children = categories.Values
                .Where(c => c.ParentCategoryId == category.Id)
                .OrderBy(c => c.Id);

            foreach (var child in children)
            {
                BuildCategoryHierarchy(child.Id, categories, result, currentPath, level + 1);
            }
        }


        private static int GetRootCategoryId(
            int categoryId,
            Dictionary<int, CategoryNode> categories)
        {
            var category = categories[categoryId];
            return category.ParentCategoryId == null
                ? category.Id
                : GetRootCategoryId(category.ParentCategoryId.Value, categories);
        }

        private static CategoryTreeDto BuildTreeWithReports(
            int categoryId,
            Dictionary<int, CategoryNode> categories,
            List<ReportPowerBIDto> reports)
        {
            if (!categories.TryGetValue(categoryId, out var category))
                return null!;

            var node = new CategoryTreeDto
            {
                Id = category.Id,
                NameAr = category.NameAr,
                NameEn = category.NameEn,
                OriginalPic = category.OriginalPic,

                Reports = reports
                    .Where(r => r.CategoryId == category.Id)
                    .ToList(),

                Children = new List<CategoryTreeDto>()
            };

            // بناء الـ Children بدون فلترة
            var children = categories.Values
                .Where(c => c.ParentCategoryId == category.Id)
                .OrderBy(c => c.Id)
                .ToList();

            foreach (var child in children)
            {
                var childNode = BuildTreeWithReports(child.Id, categories, reports);
                if (childNode != null)
                {
                    node.Children.Add(childNode);
                }
            }

            return node; // ✅ دايمًا نرجع Category
        }


        public async Task<OperationOutput> GetReportCategoriesHierarchy(int? categoryId = null)
        {
            try
            {
                var result = await GetReportCategoriesTreeFiltered(categoryId);
                if (result.Count > 0)
                {
                    ResultOutputData resultOutPut = new ResultOutputData();
                    var _result = resultOutPut.GenearetResultOutput(result, result.Count());
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<List<CategoryTreeDto>> GetReportCategoriesTreeFiltered(int? categoryId = null)
        {
            var reports = await _context.ReportPowerBI
                .AsNoTracking()
                .Where(r => r.IsActive && !r.IsDeleted)
                .Select(r => new ReportPowerBIDto
                {
                    Id = r.Id,
                    NameAr = r.NameAr,
                    NameEn = r.NameEn,
                    DescriptionAr = r.DescriptionAr,
                    DescriptionEn = r.DescriptionEn,
                    URL = r.URL,
                    OriginalPic = r.OriginalPic,
                    CategoryId = r.CategoryId
                })
                .ToListAsync();

            var categories = await _context.Categories
                .AsNoTracking()
                .Where(c => c.IsDeleted == false && c.IsActive == true && c.EntityId == (int)Enums.Entities.ReportsPowerBI)
                .Select(c => new CategoryNode
                {
                    Id = c.Id,
                    ParentCategoryId = c.ParentCategoryId,
                    NameAr = c.NameAr,
                    NameEn = c.NameEn,
                    OriginalPic = c.OriginalPic
                })
                .ToListAsync();

            if (!categories.Any())
                return new List<CategoryTreeDto>();

            var categoryDict = categories.ToDictionary(c => c.Id);

            if (categoryId.HasValue && categoryDict.ContainsKey(categoryId.Value))
            {
                var node = BuildTreeWithReports(categoryId.Value, categoryDict, reports);
                return new List<CategoryTreeDto> { node };
            }

            var rootCategories = categories
                .Where(c => c.ParentCategoryId == null)
                .OrderBy(c => c.Id)
                .ToList();

            var tree = new List<CategoryTreeDto>();
            foreach (var root in rootCategories)
            {
                var node = BuildTreeWithReports(root.Id, categoryDict, reports);
                if (node != null)
                    tree.Add(node);
            }

            return tree;
        }


        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(ReportPowerBIDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<ReportPowerBIDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<ReportPowerBIDto> entities)
        {
            throw new NotImplementedException();
        }

        public Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            throw new NotImplementedException();
        }
    }
}
