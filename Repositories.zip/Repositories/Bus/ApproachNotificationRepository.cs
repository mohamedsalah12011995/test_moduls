﻿using Core.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Nupco.Core.Dto.Buses;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces.Buses;
using Nupco.DAL;
using Nupco.DAL.Models;
using Nupco.EF.Helpers;
using System.Globalization;

namespace Nupco.EF.Repositories
{
    public class ApproachNotificationLogsRepository : BaseRepository<ApproachNotificationLog>, IApproachNotificationLogsRepository
    {
        private readonly IConfiguration? _configuration;
        private readonly IMemoryCache? _memoryCache;

        public ApproachNotificationLogsRepository(
            ApplicationDbContext context,
            ILogger logger,
            IConfiguration? configuration = null,
            IMemoryCache? memoryCache = null) : base(context, logger)
        {
            _configuration = configuration;
            _memoryCache = memoryCache;
        }

        public async Task<OperationOutput> ProcessDriverLocationUpdateAsync(DriverLocationUpdateDto dto)
        {
            try
            {
                if (dto.IsEnd)
                {
                    _logger.LogInformation(
                        "ApproachNotify: skipped because trip ended. RouteId={RouteId}, BusId={BusId}, LogId={LogId}",
                        dto.RouteId,
                        dto.BusId,
                        dto.CurrentLogId);
                    return ResultOutputData.GenearetResultOutputNoDataReturned();
                }

                if (!double.TryParse(dto.Latitude, NumberStyles.Float, CultureInfo.InvariantCulture, out double busLat) ||
                    !double.TryParse(dto.Longitude, NumberStyles.Float, CultureInfo.InvariantCulture, out double busLon))
                {
                    return ResultOutputData.GenerateResultOutputFailure(
                        "إحداثيات موقع الحافلة غير صالحة.",
                        "Invalid bus coordinates provided."
                    );
                }

                var waiterRouteId = dto.RouteId;
                var since = DateTime.Today <= DateTime.UtcNow.Date ? DateTime.Today : DateTime.UtcNow.Date;

                var transportCallQuery = _context.TransportCalls
                    .Where(tc => tc.RouteId == waiterRouteId
                              && (tc.StatusId == (int)TransportStatus.Pending
                                  || tc.StatusId == (int)TransportStatus.Assigned)
                              && tc.IsApproachNotified != true
                              && tc.CallTime >= since);

                if (dto.DriverId > 0)
                {
                    transportCallQuery = transportCallQuery.Where(tc =>
                        tc.AssignedDriverId == null || tc.AssignedDriverId == dto.DriverId);
                }

                var transportCalls = await transportCallQuery
                    .OrderByDescending(tc => tc.Id)
                    .ToListAsync();

                var notifyMeQuery = _context.NotifyMeRequests
                    .Where(nr => nr.RouteId == waiterRouteId
                              && nr.IsApproachNotified != true
                              && nr.CallTime >= since);

                if (dto.DriverId > 0)
                    notifyMeQuery = notifyMeQuery.Where(nr =>
                        nr.AssignedDriverId == null || nr.AssignedDriverId == dto.DriverId);

                var notifyMeRequests = await notifyMeQuery
                    .OrderByDescending(nr => nr.Id)
                    .ToListAsync();

                var previousPoint = await GetPreviousBusLocationAsync(dto, busLat, busLon);
                bool hasValidPrevLoc = previousPoint.HasValue;
                double prevLat = previousPoint?.Latitude ?? 0;
                double prevLon = previousPoint?.Longitude ?? 0;

                if (!transportCalls.Any() && !notifyMeRequests.Any())
                {
                    _logger.LogInformation(
                        "ApproachNotify: no pending waiters. RouteId={RouteId}, BusId={BusId}, TripNumber={TripNumber}",
                        dto.RouteId,
                        dto.BusId,
                        dto.TripNumber);
                    return ResultOutputData.GenearetResultOutputNoDataReturned();
                }

                _logger.LogInformation(
                    "ApproachNotify: matching started. RouteId={RouteId}, BusId={BusId}, LogId={LogId}, TripNumber={TripNumber}, " +
                    "BusLat={BusLat}, BusLon={BusLon}, TransportCalls={TransportCallCount}, NotifyMe={NotifyMeCount}, HasPrevGps={HasPrevGps}",
                    dto.RouteId,
                    dto.BusId,
                    dto.CurrentLogId,
                    dto.TripNumber,
                    busLat,
                    busLon,
                    transportCalls.Count,
                    notifyMeRequests.Count,
                    hasValidPrevLoc);

                // Evaluate ETA/approach using the BUS current route polyline direction (dto.RouteId),
                // not the requested waiter route direction.
                var routePolylines = await RoutePolylineLoader.LoadRoutePolylinesAsync(_context, new[] { dto.RouteId });
                routePolylines.TryGetValue(dto.RouteId, out var busRoutePolyline);

                var createdLogs = new List<ApproachNotificationLog>();
                var utcNow = DateTime.UtcNow;
                var approachingWaiters = new List<ApproachWaiterCandidate>();

                foreach (var call in transportCalls)
                {
                    var local = TryEvaluateLocalApproach(
                            "TransportCall",
                            call.Id,
                            call.RequestByUserId,
                            call.Latitude,
                            call.Longitude,
                            busLat,
                            busLon,
                            dto.TripNumber,
                            call.TripNumber,
                            hasValidPrevLoc,
                            prevLat,
                            prevLon,
                            dto.Heading,
                            busRoutePolyline);
                    if (local.IsApproaching)
                        approachingWaiters.Add(new ApproachWaiterCandidate(local, call, null));
                }

                foreach (var req in notifyMeRequests)
                {
                    var local = TryEvaluateLocalApproach(
                            "NotifyMe",
                            req.Id,
                            req.RequestByUserId,
                            req.Latitude,
                            req.Longitude,
                            busLat,
                            busLon,
                            dto.TripNumber,
                            req.TripNumber,
                            hasValidPrevLoc,
                            prevLat,
                            prevLon,
                            dto.Heading,
                            busRoutePolyline);
                    if (local.IsApproaching)
                        approachingWaiters.Add(new ApproachWaiterCandidate(local, null, req));
                }

                var googleEtas = await GoogleDrivingEtaLookup.GetBatchAsync(
                    _configuration,
                    _memoryCache,
                    _logger,
                    dto.BusId,
                    busLat,
                    busLon,
                    approachingWaiters.Select(w => (w.Local.EmpLat, w.Local.EmpLon)).ToList());

                foreach (var waiter in approachingWaiters)
                {
                    int etaSeconds = waiter.Local.EtaSeconds;
                    int distanceMeters = waiter.Local.DistanceMeters;
                    string etaSource = "local";
                    var destKey = GoogleDrivingEtaLookup.DestinationKey(waiter.Local.EmpLat, waiter.Local.EmpLon);
                    if (googleEtas.TryGetValue(destKey, out var googleEta) && googleEta.RemainingSeconds > 0)
                    {
                        etaSeconds = googleEta.RemainingSeconds;
                        if (googleEta.RemainingMeters > 0)
                            distanceMeters = Math.Max(distanceMeters, googleEta.RemainingMeters);
                        etaSource = "google_directions";
                    }

                    var notifyResult = new BusApproachResult
                    {
                        IsApproaching = true,
                        HasPassedUser = false,
                        RemainingSeconds = etaSeconds,
                        RemainingMeters = distanceMeters
                    };

                    bool alreadyArrived = distanceMeters < BusApproachCalculator.ApproachNotifyMinMeters
                        || (etaSeconds < BusApproachCalculator.ApproachNotifyMinSeconds
                            && distanceMeters < BusApproachCalculator.TerminalArrivalMeters);

                    if (alreadyArrived ||
                        !BusApproachCalculator.ShouldNotify(
                            notifyResult,
                            BusApproachCalculator.ApproachNotifyMaxSeconds,
                            minRemainingSeconds: 1,
                            minRemainingMeters: BusApproachCalculator.ApproachNotifyMinMeters))
                    {
                        string skipReason = alreadyArrived ? "already_arrived" : "eta_outside_threshold";
                        _logger.LogInformation(
                            "ApproachNotify: skipped {WaiterType} {WaiterId} user={UserId}. reason={SkipReason} etaSec={EtaSeconds} distanceM={DistanceMeters} source={EtaSource}",
                            waiter.Local.WaiterType,
                            waiter.Local.WaiterId,
                            waiter.Local.UserId,
                            skipReason,
                            etaSeconds,
                            distanceMeters,
                            etaSource);
                        continue;
                    }

                    _logger.LogInformation(
                        "ApproachNotify: matched {WaiterType} {WaiterId} user={UserId}. etaSec={EtaSeconds} distanceM={DistanceMeters} source={EtaSource}",
                        waiter.Local.WaiterType,
                        waiter.Local.WaiterId,
                        waiter.Local.UserId,
                        etaSeconds,
                        distanceMeters,
                        etaSource);

                    if (waiter.Call != null)
                    {
                        createdLogs.Add(new ApproachNotificationLog
                        {
                            TransportCallId = waiter.Call.Id,
                            NotifyMeRequestId = null,
                            UserId = waiter.Call.RequestByUserId,
                            CalculatedEtaSeconds = etaSeconds,
                            DistanceRemainingMeters = distanceMeters,
                            BusLatitude = dto.Latitude,
                            BusLongitude = dto.Longitude,
                            IsSuccess = true,
                            CreatedDate = utcNow
                        });

                        if (dto.DriverId > 0)
                            waiter.Call.AssignedDriverId = dto.DriverId;
                        waiter.Call.IsApproachNotified = true;
                        waiter.Call.ApproachNotifiedDate = utcNow;
                    }
                    else if (waiter.Request != null)
                    {
                        createdLogs.Add(new ApproachNotificationLog
                        {
                            TransportCallId = null,
                            NotifyMeRequestId = waiter.Request.Id,
                            UserId = waiter.Request.RequestByUserId,
                            CalculatedEtaSeconds = etaSeconds,
                            DistanceRemainingMeters = distanceMeters,
                            BusLatitude = dto.Latitude,
                            BusLongitude = dto.Longitude,
                            IsSuccess = true,
                            CreatedDate = utcNow
                        });

                        if (dto.DriverId > 0)
                            waiter.Request.AssignedDriverId = dto.DriverId;
                        waiter.Request.IsApproachNotified = true;
                        waiter.Request.ApproachNotifiedDate = utcNow;
                    }
                }

                if (!createdLogs.Any())
                {
                    _logger.LogInformation(
                        "ApproachNotify: no waiters met threshold. RouteId={RouteId}, BusId={BusId}, LogId={LogId}, HasPrevGps={HasPrevGps}, PolylinePoints={PolylinePoints}",
                        dto.RouteId,
                        dto.BusId,
                        dto.CurrentLogId,
                        hasValidPrevLoc,
                        busRoutePolyline?.Count ?? 0);
                    return ResultOutputData.GenerateResultOutputFailure(
                        "لم تتجاوز أي من الطلبات شروط إرسال الإشعار.",
                        "No transport calls met the notification threshold requirements."
                    );
                }

                await _context.ApproachNotificationLogs.AddRangeAsync(createdLogs);
                await _context.SaveChangesAsync();

                _logger.LogInformation(
                    "ApproachNotify: sent {Count} notification(s). RouteId={RouteId}, BusId={BusId}, LogId={LogId}, UserIds={UserIds}",
                    createdLogs.Count,
                    dto.RouteId,
                    dto.BusId,
                    dto.CurrentLogId,
                    string.Join(",", createdLogs.Select(l => l.UserId).Distinct()));

                return new ResultOutputData().GenearetResultOutput(createdLogs, createdLogs.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing driver location update for RouteId: {RouteId}, DriverId: {DriverId}", dto.RouteId, dto.DriverId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> NotifyMeAsync(CreateNotifyMeRequestDto dto)
        {
            try
            {
                // Check existing request by UserId and RouteId
                var existingRequest = await _context.NotifyMeRequests
                    .FirstOrDefaultAsync(x => x.RequestByUserId == dto.RequestByUserId
                                           && x.RouteId == dto.RouteId && x.TripNumber == dto.TripNumber);

                NotifyMeRequest resultEntity;

                if (existingRequest != null)
                {
                    // Reset notification status if existing request re-enables
                    existingRequest.IsApproachNotified = false;
                    existingRequest.ApproachNotifiedDate = null;
                    existingRequest.TripNumber = dto.TripNumber;
                    existingRequest.Latitude = dto.Latitude;
                    existingRequest.Longitude = dto.Longitude;
                    existingRequest.AssignedDriverId = dto.AssignedDriverId;
                    existingRequest.Note = dto.Note;

                    resultEntity = existingRequest;
                }
                else
                {
                    // Create new NotifyMeRequest
                    var newRequest = new NotifyMeRequest
                    {
                        RequestByUserId = dto.RequestByUserId,
                        RouteId = dto.RouteId,
                        AssignedDriverId = dto.AssignedDriverId,
                        TripNumber = dto.TripNumber,
                        Latitude = dto.Latitude,
                        Longitude = dto.Longitude,
                        Note = dto.Note,
                        CallTime = DateTime.UtcNow,
                        IsApproachNotified = false
                    };

                    await _context.NotifyMeRequests.AddAsync(newRequest);
                    resultEntity = newRequest;
                }

                await _context.SaveChangesAsync();

                return new ResultOutputData().GenearetResultOutput(resultEntity, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating NotifyMe status for UserId: {UserId}", dto.RequestByUserId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> ConfirmNotificationDeliveryAsync(NotificationDeliveredDto dto)
        {
            try
            {
                var logEntity = await _context.ApproachNotificationLogs
                    .FirstOrDefaultAsync(x => x.Id == dto.LogId && x.TransportCallId == dto.TransportCallId);

                if (logEntity == null)
                {
                    return ResultOutputData.GenearetResultOutputNoDataReturned();
                }

                logEntity.DeliveredDate = dto.DeliveredDate;
                await _context.SaveChangesAsync();

                return new ResultOutputData().GenearetResultOutput(logEntity, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error confirming notification delivery for LogId: {LogId}", dto.LogId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetLogsByTransportCallIdAsync(int transportCallId)
        {
            try
            {
                var logs = await _context.ApproachNotificationLogs
                    .AsNoTracking()
                    .Where(x => x.TransportCallId == transportCallId)
                    .OrderByDescending(x => x.CreatedDate)
                    .Select(x => new ApproachNotificationLogDto
                    {
                        Id = x.Id,
                        TransportCallId = x.TransportCallId.Value,
                        UserId = x.UserId,
                        CalculatedEtaSeconds = x.CalculatedEtaSeconds.Value,
                        DistanceRemainingMeters = x.DistanceRemainingMeters,
                        BusLatitude = x.BusLatitude,
                        BusLongitude = x.BusLongitude,
                        IsSuccess = x.IsSuccess.Value,
                        ErrorMessage = x.ErrorMessage,
                        CreatedDate = x.CreatedDate,
                        DeliveredDate = x.DeliveredDate
                    })
                    .ToListAsync();

                return new ResultOutputData().GenearetResultOutput(logs, logs.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching notification logs for CallId: {CallId}", transportCallId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        #region Helper Methods

        private async Task<(double Latitude, double Longitude)?> GetPreviousBusLocationAsync(
            DriverLocationUpdateDto dto,
            double currentLat,
            double currentLon)
        {
            if (!dto.BusId.HasValue && dto.DriverId <= 0)
                return null;

            var prevQuery = _context.BusLocationLogs
                .AsNoTracking()
                .Where(b => !b.IsDeleted && !b.IsEnd);

            if (dto.CurrentLogId.HasValue)
                prevQuery = prevQuery.Where(b => b.Id < dto.CurrentLogId.Value);

            if (dto.BusId.HasValue)
                prevQuery = prevQuery.Where(b => b.BusId == dto.BusId);
            else
                prevQuery = prevQuery.Where(b => b.DriverId == dto.DriverId);

            var recentLogs = await prevQuery
                .OrderByDescending(b => b.Id)
                .Take(15)
                .Select(b => new { b.Latitude, b.Longitude })
                .ToListAsync();

            foreach (var log in recentLogs)
            {
                if (BusApproachCalculator.HasMeaningfulMovement(currentLat, currentLon, log.Latitude, log.Longitude))
                    return (log.Latitude, log.Longitude);
            }

            return null;
        }

        private sealed class ApproachWaiterCandidate
        {
            public ApproachWaiterCandidate(LocalApproachEvaluation local, TransportCall? call, NotifyMeRequest? request)
            {
                Local = local;
                Call = call;
                Request = request;
            }

            public LocalApproachEvaluation Local { get; }
            public TransportCall? Call { get; }
            public NotifyMeRequest? Request { get; }
        }

        private readonly struct LocalApproachEvaluation
        {
            public bool IsApproaching { get; init; }
            public string WaiterType { get; init; }
            public int WaiterId { get; init; }
            public string? UserId { get; init; }
            public double EmpLat { get; init; }
            public double EmpLon { get; init; }
            public int EtaSeconds { get; init; }
            public int DistanceMeters { get; init; }
        }

        private LocalApproachEvaluation TryEvaluateLocalApproach(
            string waiterType,
            int waiterId,
            string? userId,
            string userLatitude,
            string userLongitude,
            double busLat,
            double busLon,
            int? busTripNumber,
            int? waiterTripNumber,
            bool hasValidPrevLoc,
            double prevLat,
            double prevLon,
            int? gpsHeading,
            IReadOnlyList<RoutePolylinePoint>? routePolyline)
        {
            if (busTripNumber.HasValue && waiterTripNumber.HasValue && busTripNumber.Value < waiterTripNumber.Value)
            {
                _logger.LogInformation(
                    "ApproachNotify: skipped {WaiterType} {WaiterId} user={UserId}. reason=trip_not_started busTrip={BusTrip} waiterTrip={WaiterTrip}",
                    waiterType,
                    waiterId,
                    userId,
                    busTripNumber,
                    waiterTripNumber);
                return default;
            }

            if (!RoutePolylineHelper.TryParseCoordinate(userLatitude, out double empLat) ||
                !RoutePolylineHelper.TryParseCoordinate(userLongitude, out double empLon))
            {
                _logger.LogInformation(
                    "ApproachNotify: skipped {WaiterType} {WaiterId} user={UserId}. reason=invalid_user_coordinates lat={Lat} lon={Lon}",
                    waiterType,
                    waiterId,
                    userId,
                    userLatitude,
                    userLongitude);
                return default;
            }

            var evaluation = BusApproachCalculator.EvaluateDetailed(
                busLat,
                busLon,
                hasValidPrevLoc ? prevLat : null,
                hasValidPrevLoc ? prevLon : null,
                empLat,
                empLon,
                routePolyline,
                gpsHeading,
                forNotification: false);

            if (evaluation.Result.HasPassedUser || !evaluation.Result.IsApproaching)
            {
                var skipReason = evaluation.Result.HasPassedUser ? "passed_user" : "not_approaching";
                _logger.LogInformation(
                    "ApproachNotify: skipped {WaiterType} {WaiterId} user={UserId}. reason={SkipReason}. {Details}",
                    waiterType,
                    waiterId,
                    userId,
                    skipReason,
                    evaluation.ToLogString());
                return default;
            }

            return new LocalApproachEvaluation
            {
                IsApproaching = true,
                WaiterType = waiterType,
                WaiterId = waiterId,
                UserId = userId,
                EmpLat = empLat,
                EmpLon = empLon,
                EtaSeconds = evaluation.Result.RemainingSeconds,
                DistanceMeters = evaluation.Result.RemainingMeters
            };
        }

        #endregion

        private async Task<List<int>> GetOppositeRouteIdsAsync(int routeId)
        {
            var receivedRoute = await _context.Routes
                .AsNoTracking()
                .Where(r => r.Id == routeId && r.IsActive && !r.IsDeleted)
                .Select(r => new { r.StartLocationId, r.EndLocationId })
                .FirstOrDefaultAsync();

            if (receivedRoute == null ||
                !receivedRoute.StartLocationId.HasValue ||
                !receivedRoute.EndLocationId.HasValue)
            {
                // Fallback: notify on the same route id if we can't resolve direction.
                return new List<int> { routeId };
            }

            var startLoc = receivedRoute.StartLocationId.Value;
            var endLoc = receivedRoute.EndLocationId.Value;

            var oppositeRouteIds = await _context.Routes
                .AsNoTracking()
                .Where(r => r.IsActive && !r.IsDeleted &&
                            r.StartLocationId == endLoc &&
                            r.EndLocationId == startLoc)
                .Select(r => r.Id)
                .ToListAsync();

            return oppositeRouteIds.Count == 0 ? new List<int> { routeId } : oppositeRouteIds;
        }
    }
}