﻿using Core.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Dto.Buses;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Nupco.EF.Repositories
{
    internal class BusRepository : BaseRepository<Bus>, IBusRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly Bus_Assembler _Bus_Assembler;

        private string[] stringArray = { "Route" };


        public BusRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _Bus_Assembler = new Bus_Assembler();
            _logger = logger;
            _context = context;

        }


        public async Task<OperationOutput> BusOnOff(int id, bool isOn)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id && f.IsDeleted == false);
                if (find is null)
                {
                    var noData = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return noData;
                }

                find.IsOn = isOn;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(BusObjDto entity)
        {
            try
            {
                entity.IsActive = true;
                var _model = _Bus_Assembler.WriteDal(entity);
                var _entity = await AddAsync(_model);
                await _context.SaveChangesAsync();


                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(_entity, 1);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDeleted = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            try
            {
                var spec = Specification<Bus>.All.And(new BusSpecification(_filter));

                var Bus = await FindAllAsync(i => i.IsDeleted == false, (int)_filter.pageNumber * (int)_filter.pageSize, (int)_filter.pageSize,stringArray);
                var _Bus = _Bus_Assembler.WriteListDto(Bus);
                var counts = await CountAsync(i => i.IsDeleted == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_Bus, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false, stringArray);
                var _entities = _Bus_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var Bus = await GetByIdAsync(id);
                if (Bus != null)
                {
                    var _Bus = _Bus_Assembler.WriteDto(Bus);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_Bus, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> UpadteRouteBusById(int id, int routeId)
        {
            try
            {
                var Bus = await GetByIdAsync(id);
                if (Bus != null)
                {
                    Bus.RouteId = routeId;

                    var _model = Update(Bus);
                    await SaveChangesAsync();

                    var _Bus = _Bus_Assembler.WriteDto(_model);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_Bus, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> UpdateEntity(BusObjDto entity)
        {
            try
            {

                var _entity = await FindAsync(i => i.Id == entity.Id);
                if (_entity is not null)
                {
                    _entity.IsActive = true;
                    _entity.IsDeleted = false;
                    _entity.NameAr = entity.NameAr;
                    _entity.NameEn = entity.NameEn;
                    _entity.Code = entity.Code;
                    _entity.Notes= entity.Notes;
                    _entity.Capacity = entity.Capacity;
                    _entity.PlateNumber = entity.PlateNumber;
                    _entity.RouteId= entity.RouteId;
                    var _model =  Update(_entity);
                    await SaveChangesAsync();

                    ResultOutputData resultOutput = new ResultOutputData();
                    var _result = resultOutput.GenearetResultOutput(_model, 1);
                    return _result;
                }

                else
                {
                    var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return Result;
                }

            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }

        public async Task<OperationOutput> GetAllPagenationBusesWithDetails(FiltersBy _filter)
        {
            try
            {
                string[] stringArray = new string[] { "Drivers", "Route" };

                var spec = Specification<Bus>.All.And(new BusSpecification(_filter));
                var busesList = await FindAllAsync(
                    spec.ToExpression(),
                    (int)_filter.pageNumber * (int)_filter.pageSize,
                    (int)_filter.pageSize,
                    stringArray
                );

                var counts = await CountAsync(spec.ToExpression());

                var nowUtc = DateTime.UtcNow;
                var today = nowUtc.Date;

                var _BusDtoList = busesList
                    .Select(b =>
                    {
                        bool calculatedIsOn = false;

                        if (b.DistanceTodayDate.HasValue)
                        {
                            var localDate = DateTime.SpecifyKind(b.DistanceTodayDate.Value, DateTimeKind.Local);
                            var utcLastDate = localDate.ToUniversalTime();

                            var minutesPassed = (nowUtc - utcLastDate).TotalMinutes;
                            calculatedIsOn = minutesPassed >= 0 && minutesPassed <= 5;
                        }

                        return new BusDetailsDto
                        {
                            BusId = b.Id,
                            BusCode = b.Code,
                            BusNameAr = b.NameAr,
                            BusNameEn = b.NameEn,
                            PlateNumber = b.PlateNumber,
                            Capacity = b.Capacity,
                            IsActive = b.IsActive,
                            Notes = b.Notes,
                            DistanceSinceAppStartKm = b.DistanceSinceAppStartKm,

                            DistanceTodayDate = b.DistanceTodayDate,
                            DistanceTodayKm = (b.DistanceTodayDate.HasValue && b.DistanceTodayDate.Value.Date == today)
                                                ? b.DistanceTodayKm
                                                : 0,

                            IsOn = calculatedIsOn,
                            LastLatitude = b.LastLatitude,
                            LastLongitude = b.LastLongitude,

                            Drivers = b.Drivers != null ? b.Drivers.Select(d => new DriverInfoDto
                            {
                                DriverId = d.Id,
                                DriverName = d.FirstName + " " + d.LastName,
                                DriverMobile = d.MobileNumber,
                                DriverUserName = d.UserName,
                                DriverLicense = d.LicenseNumber,
                                IsActive = d.IsActive
                            }).ToList() : new List<DriverInfoDto>(),

                            Routes = b.Route != null ? new List<RouteInfoDto>
                            {
                        new RouteInfoDto
                        {
                            RouteId = b.Route.Id,
                            RouteCode = b.Route.Code,
                            RouteNameAr = b.Route.NameAr,
                            RouteNameEn = b.Route.NameEn,
                            RouteDirection = b.Route.DirectionType,
                            RouteDistanceKm = b.Route.DistanceKm,
                            TotalStopsCount = b.Route.RouteStops != null ? b.Route.RouteStops.Count : 0
                        }
                            } : new List<RouteInfoDto>()
                        };
                    })
                    .ToList();

                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_BusDtoList, counts);

                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }
        public Task<OperationOutput> UpdateEntityAsync(BusDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<BusDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<BusDto> entities)
        {
            throw new NotImplementedException();
        }
    }
}
