﻿using Core.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Dto.Buses;
using Nupco.Core.Helpers;
using Nupco.EF.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using YourProject.DAL.Models.Buses;
using Location = Nupco.DAL.Models.Location;

namespace Nupco.EF.Repositories
{
    internal class BusLocationLogRepository : BaseRepository<BusLocationLog>, IBusLocationLogRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly IConfiguration? _configuration;
        private readonly IMemoryCache? _memoryCache;
        private readonly BusLocationLog_Assembler _BusLocationLog_Assembler;

        private string[] stringArray = { "Bus", "Driver", "Route", "BusStatus",  "NearestLocation" };


        public BusLocationLogRepository(
            ApplicationDbContext context,
            ILogger logger,
            IConfiguration? configuration = null,
            IMemoryCache? memoryCache = null) : base(context, logger)
        {
            _BusLocationLog_Assembler = new BusLocationLog_Assembler();
            _logger = logger;
            _context = context;
            _configuration = configuration;
            _memoryCache = memoryCache;
        }

        public async Task<Location> GetNearestLocationId(double busLatitude, double busLongitude, double maxDistanceKm = 0.5, CancellationToken cancellationToken = default)
        {
            Location nearest = null;
            double minDistance = double.MaxValue;

            // Only project needed columns — full entity load was slow and caused client timeouts / TaskCanceledException.
            var candidates = await _context.Locations
                .AsNoTracking()
                .Where(i => !i.IsDeleted && i.Latitude != null && i.Longitude != null)
                .Select(i => new { i.Id, i.Latitude, i.Longitude })
                .ToListAsync(cancellationToken);

            foreach (var location in candidates)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (!double.TryParse(location.Latitude, System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out var locLat) &&
                    !double.TryParse(location.Latitude, out locLat))
                {
                    continue;
                }

                if (!double.TryParse(location.Longitude, System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out var locLon) &&
                    !double.TryParse(location.Longitude, out locLon))
                {
                    continue;
                }

                var distance = GeoDistanceCalculator.CalculateHaversineDistance(
                    busLatitude, busLongitude, locLat, locLon);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    nearest = new Location { Id = location.Id };
                }
            }

            if (minDistance <= maxDistanceKm && nearest != null)
            {
                return nearest;
            }

            return null;
        }

        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(BusLocationLogObjDto entity)
        {
            try
            {
                if (entity == null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned("Invalid request payload");

                var _model = _BusLocationLog_Assembler.WriteDal(entity);

                if (!_model.BusStatusId.HasValue || _model.BusStatusId.Value <= 0)
                {
                    _model.BusStatusId = null;
                }
                else
                {
                    var statusExists = await _context.BusStatusLookups
                        .AsNoTracking()
                        .AnyAsync(s => s.Id == _model.BusStatusId.Value);

                    if (!statusExists)
                    {
                        _logger.LogWarning(
                            "CreateBusLocationLog: BusStatusId {BusStatusId} not found — saving as null",
                            _model.BusStatusId);
                        _model.BusStatusId = null;
                    }
                }

                _model.NearestLocationId = null;

                var bus = await _context.Buses.FirstOrDefaultAsync(b => b.Id == entity.BusId);

                if (bus != null)
                {
                    DateTime today = DateTime.Now.Date;

                    if (!bus.DistanceTodayDate.HasValue || bus.DistanceTodayDate.Value.Date != today)
                    {
                        bus.DistanceTodayKm = 0;
                        bus.DistanceTodayDate = today;
                    }

                    double deltaDistance = 0;

                    bool hasValidLastLocation = bus.LastLatitude.HasValue && bus.LastLongitude.HasValue
                                                 && bus.LastLatitude.Value != 0 && bus.LastLongitude.Value != 0;

                    bool hasValidNewLocation = entity.Latitude != 0 && entity.Longitude != 0;

                    if (hasValidLastLocation && hasValidNewLocation)
                    {
                        deltaDistance = DistanceCalculator.CalculateDistance(
                            bus.LastLatitude.Value, bus.LastLongitude.Value,
                            entity.Latitude, entity.Longitude
                        );

                        if (deltaDistance < 0.01)
                        {
                            deltaDistance = 0;
                        }
                        else
                        {
                            deltaDistance = Math.Round(deltaDistance, 3);
                        }
                    }

                    if (!bus.IsOn.HasValue)
                        bus.IsOn = true;
                    
                        double currentTodayKm = bus.DistanceTodayKm ?? 0;
                        double currentAppStartKm = bus.DistanceSinceAppStartKm ?? 0;

                        bus.DistanceTodayKm = Math.Round(currentTodayKm + deltaDistance, 3);
                        bus.DistanceSinceAppStartKm = Math.Round(currentAppStartKm + deltaDistance, 3);

                    if (hasValidNewLocation)
                    {
                        bus.LastLatitude = entity.Latitude;
                        bus.LastLongitude = entity.Longitude;
                        bus.DistanceTodayDate = DateTime.Now;
                    }

                    _context.Buses.Update(bus);
                }

                _model.LoggedAt = DateTime.Now;
                _model.TripNumber = entity.TripNumber;
                _model.IsEnd = entity.IsEnd;
                _model.Heading = entity.Heading;
                _model.Source = entity.Source;
                _model.SpeedKmh = await CalculateSpeedKmhAsync(
                    entity.BusId,
                    _model.Latitude,
                    _model.Longitude,
                    _model.LoggedAt);
                _model.IsActive = true;
                _model.IsDeleted = false;

                var _entity = await AddAsync(_model);
                await _context.SaveChangesAsync();

                var responseDto = new BusLocationLogObjDto
                {
                    Id = _entity.Id,
                    BusId = _entity.BusId,
                    DriverId = _entity.DriverId,
                    RouteId = _entity.RouteId,
                    BusStatusId = _entity.BusStatusId,
                    LoggedAt = _entity.LoggedAt,
                    Latitude = _entity.Latitude,
                    Longitude = _entity.Longitude,
                    SpeedKmh = _entity.SpeedKmh,
                    Heading = _entity.Heading,
                    Source = _entity.Source,
                    NearestLocationId = _entity.NearestLocationId,
                    TripNumber = _entity.TripNumber,
                    IsEnd = _entity.IsEnd
                };

                ResultOutputData resultOutput = new ResultOutputData();
                return resultOutput.GenearetResultOutputWithOutJWT(responseDto, 1);
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogWarning(ex,
                    "CreateBusLocationLog canceled (client disconnect/timeout). BusId={BusId}",
                    entity?.BusId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "CreateBusLocationLog failed. BusId={BusId}, DriverId={DriverId}, RouteId={RouteId}, BusStatusId={BusStatusId}",
                    entity?.BusId, entity?.DriverId, entity?.RouteId, entity?.BusStatusId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDeleted = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FilterByBusLocationLog _filter)
        {
            try
            {
                var spec = Specification<BusLocationLog>.All.And(new BusLocationLogSpecification(_filter));

                var entites = await _context.BusLocationLogs
                    .Where(spec.ToExpression())
                    .Where(i=> !i.IsDeleted)
                    .Include(i => i.Bus)
                    .Include(i => i.Route)
                    .Include(i => i.Driver)
                    .OrderByDescending(o => o.Id)
                    .Skip((int)_filter.pageNumber * (int)_filter.pageSize).Take((int)_filter.pageSize)
                     .AsNoTrackingWithIdentityResolution().ToListAsync();

                var BusLocationLog = entites.Where(i => i.IsDeleted == false).ToList();
                var _BusLocationLog = _BusLocationLog_Assembler.WriteListDto(BusLocationLog);
                var counts = await CountAsync(i => i.IsDeleted == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_BusLocationLog, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false, stringArray);
                var _entities = _BusLocationLog_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var BusLocationLog = await GetByIdAsync(id);
                if (BusLocationLog != null)
                {
                    var _BusLocationLog = _BusLocationLog_Assembler.WriteDto(BusLocationLog);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_BusLocationLog, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> UpdateEntity(BusLocationLogObjDto entity)
        {
            try
            {

                var _entity = await FindAsync(i => i.Id == entity.Id);
                if (_entity is not null)
                {
                    _entity.IsActive = true;
                    _entity.IsDeleted = false;
                    _entity.RouteId = entity.RouteId;
                    _entity.DriverId = entity.DriverId;
                    _entity.BusId = entity.BusId;
                    _entity.NearestLocationId = entity.NearestLocationId;
                    _entity.BusStatusId= entity.BusStatusId;
                    _entity.Latitude = entity.Latitude;
                    _entity.Longitude = entity.Longitude;
                    _entity.SpeedKmh = await CalculateSpeedKmhAsync(
                        entity.BusId ?? _entity.BusId,
                        _entity.Latitude,
                        _entity.Longitude,
                        _entity.LoggedAt,
                        excludeLogId: _entity.Id);
                    _entity.Heading = entity.Heading;
                    _entity.Source = entity.Source;
                    if (entity.TripNumber.HasValue)
                        _entity.TripNumber = entity.TripNumber;
                    _entity.IsEnd = entity.IsEnd;
                    if (!entity.BusStatusId.HasValue || entity.BusStatusId.Value <= 0)
                        _entity.BusStatusId = null;
                    else
                        _entity.BusStatusId = entity.BusStatusId;

                    Update(_entity);
                    await SaveChangesAsync();

                    var responseDto = new BusLocationLogObjDto
                    {
                        Id = _entity.Id,
                        BusId = _entity.BusId,
                        DriverId = _entity.DriverId,
                        RouteId = _entity.RouteId,
                        BusStatusId = _entity.BusStatusId,
                        LoggedAt = _entity.LoggedAt,
                        Latitude = _entity.Latitude,
                        Longitude = _entity.Longitude,
                        SpeedKmh = _entity.SpeedKmh,
                        Heading = _entity.Heading,
                        Source = _entity.Source,
                        NearestLocationId = _entity.NearestLocationId,
                        TripNumber = _entity.TripNumber,
                        IsEnd = _entity.IsEnd
                    };

                    ResultOutputData resultOutput = new ResultOutputData();
                    var _result = resultOutput.GenearetResultOutputWithOutJWT(responseDto, 1);
                    return _result;
                }

                else
                {
                    var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return Result;
                }

            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }

        public async Task<OperationOutput> GetLookupsBussModule()
        {
            try
            {
                var data = await _context.BusLocationLogs
                    .AsNoTracking()
                    .Select(x => new
                    {
                        x.BusId,
                        BusNameAr = x.Bus.NameAr,
                        BusNameEn = x.Bus.NameEn,

                        x.RouteId,
                        RouteNameAr = x.Route.NameAr,
                        RouteNameEn = x.Route.NameEn,

                        x.DriverId,
                        DriverNameAr = x.Driver.FirstName + " " + x.Driver.LastName,
                        DriverNameEn = x.Driver.UserName
                    })
                    .ToListAsync();

                var result = new
                {
                    Buses = data
                        .Where(x => x.BusId != null)
                        .Select(x => new
                        {
                            Id = x.BusId.Value,
                            x.BusNameAr,
                            x.BusNameEn
                        })
                        .Distinct()
                        .ToList(),

                    Routes = data
                        .Where(x => x.RouteId != null)
                        .Select(x => new
                        {
                            Id = x.RouteId.Value,
                            x.RouteNameAr,
                            x.RouteNameEn
                        })
                        .Distinct()
                        .ToList(),

                    Drivers = data
                        .Where(x => x.DriverId != null)
                        .Select(x => new
                        {
                            Id = x.DriverId.Value,
                            x.DriverNameAr,
                            x.DriverNameEn
                        })
                        .Distinct()
                        .ToList()
                };

                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(result, 1);
                return _result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Fast lookup error");
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }



        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(BusLocationLogDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<BusLocationLogDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<BusLocationLogDto> entities)
        {
            throw new NotImplementedException();
        }

        public Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            throw new NotImplementedException();
        }

        public async Task<BusLocationLiveDto?> GetEnrichedLogAsync(int logId)
        {
            var log = await _context.BusLocationLogs
                .AsNoTracking()
                .Include(l => l.Bus)
                .Include(l => l.Driver)
                .Include(l => l.Route).ThenInclude(r => r.StartLocation)
                .Include(l => l.Route).ThenInclude(r => r.EndLocation)
                .FirstOrDefaultAsync(l => l.Id == logId);

            if (log == null) return null;

            return MapToLiveDto(log);
        }

        public async Task<OperationOutput> GetLastLocationByBusIdAsync(
            int busId,
            string userId,
            double userLatitude,
            double userLongitude,
            int? routeId = null)
        {
            try
            {
                var logId = await _context.BusLocationLogs
                    .AsNoTracking()
                    .Where(l => l.BusId == busId && !l.IsDeleted)
                    .OrderByDescending(l => l.Id)
                    .Select(l => (int?)l.Id)
                    .FirstOrDefaultAsync();

                if (logId == null)
                {
                    _logger.LogWarning("GetLastLocationByBusIdAsync: no logs for bus {BusId}", busId);
                    return ResultOutputData.GenearetResultOutputNoDataReturned($"No location log found for bus {busId}");
                }

                var log = await _context.BusLocationLogs
                    .AsNoTracking()
                    .Include(l => l.Bus)
                    .Include(l => l.Driver)
                    .Include(l => l.Route).ThenInclude(r => r.StartLocation)
                    .Include(l => l.Route).ThenInclude(r => r.EndLocation)
                    .Include(l => l.BusStatus)
                    .Include(l => l.NearestLocation)
                    .FirstOrDefaultAsync(l => l.Id == logId.Value);

                if (log == null)
                {
                    _logger.LogWarning("GetLastLocationByBusIdAsync: log {LogId} not found for bus {BusId}", logId, busId);
                    return ResultOutputData.GenearetResultOutputNoDataReturned($"No location log found for bus {busId}");
                }

                var previousLog = await _context.BusLocationLogs
                    .AsNoTracking()
                    .Where(l => l.BusId == busId && !l.IsDeleted && !l.IsEnd && l.Id < log.Id)
                    .OrderByDescending(l => l.Id)
                    .Select(l => new { l.Latitude, l.Longitude })
                    .FirstOrDefaultAsync();

                var liveDto = MapToLiveDto(log);

                if (log.Bus?.LastLatitude is double lastLat &&
                    log.Bus?.LastLongitude is double lastLon &&
                    lastLat != 0 && lastLon != 0)
                {
                    liveDto.Lat = lastLat;
                    liveDto.Long = lastLon;
                    log.Latitude = lastLat;
                    log.Longitude = lastLon;
                }
                liveDto.IsNotifyMeEnabled = true;
                liveDto.IsRequestRideEnabled = true;
                liveDto.HasActiveNotifyMe = false;
                liveDto.HasActiveTransportCall = false;
                liveDto.HasBusPassedUser = false;

                await EnrichEmployeeContextAsync(
                    liveDto,
                    userId,
                    userLatitude,
                    userLongitude,
                    routeId ?? log.RouteId ?? log.Bus?.RouteId,
                    log,
                    previousLog?.Latitude,
                    previousLog?.Longitude);

                _logger.LogInformation(
                    "GetLastLocationByBusIdAsync: bus {BusId} -> log {LogId}, tripNumber={TripNumber}, lat={Lat}, lng={Lng}, remainingMinutes={RemainingMinutes}",
                    busId, log.Id, liveDto.TripNumber, liveDto.Lat, liveDto.Long, liveDto.RemainingMinutes);

                ResultOutputData result = new ResultOutputData();
                return result.GenearetResultOutputWithOutJWT(liveDto, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetLastLocationByBusIdAsync failed for bus {BusId}", busId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        private async Task EnrichEmployeeContextAsync(
            BusLocationLiveDto liveDto,
            string userId,
            double userLatitude,
            double userLongitude,
            int? routeId,
            BusLocationLog currentLog,
            double? previousBusLat,
            double? previousBusLon)
        {
            var localToday = DateTime.Today;
            var localTomorrow = localToday.AddDays(1);
            var utcToday = DateTime.UtcNow.Date;
            var utcTomorrow = utcToday.AddDays(1);
            List<int> routeIds = new();

            if (routeId.HasValue)
                routeIds = await RoutePolylineLoader.GetRouteAndOppositeIdsAsync(_context, routeId.Value);

            var notifyMe = await _context.NotifyMeRequests
                .AsNoTracking()
                .Where(nr => nr.RequestByUserId == userId
                          && nr.CallTime >= utcToday
                          && nr.CallTime < utcTomorrow
                          && (!routeId.HasValue || (nr.RouteId.HasValue && routeIds.Contains(nr.RouteId.Value))))
                .OrderByDescending(nr => nr.Id)
                .FirstOrDefaultAsync();

            var transportCall = await _context.TransportCalls
                .AsNoTracking()
                .Where(tc => tc.RequestByUserId == userId
                          && tc.CallTime >= localToday
                          && tc.CallTime < localTomorrow
                          && (!routeId.HasValue || (tc.RouteId.HasValue && routeIds.Contains(tc.RouteId.Value))))
                .OrderByDescending(tc => tc.Id)
                .FirstOrDefaultAsync();

            bool boardedToday = await HasEmployeeBoardedTodayAsync(userId, busId: liveDto.BusId, routeId);

            List<RoutePolylinePoint>? polyline = null;
            // Remaining time is ETA to the route destination. Use the bus current route direction.
            var polylineRouteId = currentLog.RouteId ?? routeId ?? notifyMe?.RouteId ?? transportCall?.RouteId;
            if (polylineRouteId.HasValue)
            {
                var polylines = await RoutePolylineLoader.LoadRoutePolylinesAsync(_context, new[] { polylineRouteId.Value });
                polylines.TryGetValue(polylineRouteId.Value, out polyline);
            }

            BusApproachEvaluationContext evaluation = BusApproachCalculator.EvaluateDetailed(
                currentLog.Latitude,
                currentLog.Longitude,
                previousBusLat,
                previousBusLon,
                userLatitude,
                userLongitude,
                polyline,
                gpsHeading: null,
                forNotification: false);

            liveDto.HasBusPassedUser = evaluation.Result.HasPassedUser;

            var route = currentLog.Route ?? currentLog.Bus?.Route;
            TryParseLocationCoordinates(route?.StartLocation, out double? startLat, out double? startLon);
            TryParseLocationCoordinates(route?.EndLocation, out double? endLat, out double? endLon);

            var destinationEta = await EstimateRemainingToDestinationAsync(
                currentLog,
                polyline,
                startLat,
                startLon,
                endLat,
                endLon,
                route?.DistanceKm);

            if (destinationEta.HasValue)
            {
                int totalSeconds = destinationEta.Value.RemainingSeconds;
                liveDto.RemainingMinutes = totalSeconds / 60;
                liveDto.RemainingSeconds = totalSeconds % 60;

                if (destinationEta.Value.EffectiveHeading.HasValue &&
                    destinationEta.Value.EffectiveHeading != currentLog.Heading)
                {
                    ApplyHeadingEndpoints(
                        destinationEta.Value.EffectiveHeading,
                        route,
                        liveDto.Source,
                        out var source,
                        out var destination);
                    liveDto.Source = source;
                    liveDto.Destination = destination;
                    liveDto.Heading = destinationEta.Value.EffectiveHeading;
                }
            }

            _logger.LogInformation(
                "GetLastLocation ETA: busId={BusId}, userId={UserId}, logId={LogId}, routeId={RouteId}, remainMin={RemainingMinutes}, remainSec={RemainingSeconds}, destEta={DestEtaSource}. {Details}",
                liveDto.BusId,
                userId,
                currentLog.Id,
                polylineRouteId,
                liveDto.RemainingMinutes,
                liveDto.RemainingSeconds,
                destinationEta?.Source ?? "none",
                evaluation.ToLogString());

            // Buttons disabled only while waiting for the 1-min approach notification.
            // Re-enable after notification is sent (IsApproachNotified = true).
            bool hasActiveNotifyMe = notifyMe != null
                && !boardedToday
                && notifyMe.IsApproachNotified != true;

            bool hasActiveTransportCall = transportCall != null
                && transportCall.StatusId <= 2
                && !boardedToday
                && transportCall.IsApproachNotified != true;

            liveDto.HasActiveNotifyMe = hasActiveNotifyMe;
            liveDto.HasActiveTransportCall = hasActiveTransportCall;
            liveDto.IsNotifyMeEnabled = !hasActiveNotifyMe;
            liveDto.IsRequestRideEnabled = !hasActiveTransportCall;
        }

        private readonly struct DestinationRemaining
        {
            public int RemainingSeconds { get; init; }
            public int RemainingMeters { get; init; }
            public string Source { get; init; }
            public int? EffectiveHeading { get; init; }
        }

        private async Task<DestinationRemaining?> EstimateRemainingToDestinationAsync(
            BusLocationLog currentLog,
            IReadOnlyList<RoutePolylinePoint>? polyline,
            double? startLat,
            double? startLon,
            double? endLat,
            double? endLon,
            decimal? routeDistanceKm)
        {
            if (!BusApproachCalculator.TryGetHeadingDestination(
                    currentLog.Heading,
                    startLat,
                    startLon,
                    endLat,
                    endLon,
                    polyline,
                    out double destLat,
                    out double destLon))
            {
                return FromLocalEstimate(currentLog, polyline, startLat, startLon, endLat, endLon, routeDistanceKm, currentLog.Heading);
            }

            double distanceToDestMeters = GeoDistanceCalculator.CalculateHaversineDistance(
                currentLog.Latitude,
                currentLog.Longitude,
                destLat,
                destLon) * 1000.0;

            int? etaHeading = currentLog.Heading;
            // Arrived at point 2 (or point 1): remaining time is the trip to the opposite terminal.
            if (distanceToDestMeters <= BusApproachCalculator.TerminalArrivalMeters)
            {
                var returnHeading = BusApproachCalculator.OppositeHeading(currentLog.Heading);
                if (!returnHeading.HasValue ||
                    !BusApproachCalculator.TryGetHeadingDestination(
                        returnHeading,
                        startLat,
                        startLon,
                        endLat,
                        endLon,
                        polyline,
                        out destLat,
                        out destLon))
                {
                    return new DestinationRemaining
                    {
                        RemainingSeconds = 0,
                        RemainingMeters = (int)Math.Round(distanceToDestMeters),
                        Source = "arrived",
                        EffectiveHeading = currentLog.Heading
                    };
                }

                double distanceToReturnMeters = GeoDistanceCalculator.CalculateHaversineDistance(
                    currentLog.Latitude,
                    currentLog.Longitude,
                    destLat,
                    destLon) * 1000.0;

                if (distanceToReturnMeters <= BusApproachCalculator.TerminalArrivalMeters)
                {
                    return new DestinationRemaining
                    {
                        RemainingSeconds = 0,
                        RemainingMeters = 0,
                        Source = "arrived",
                        EffectiveHeading = currentLog.Heading
                    };
                }

                etaHeading = returnHeading;
                distanceToDestMeters = distanceToReturnMeters;
            }

            var googleEta = await GetGoogleDrivingEtaAsync(
                currentLog.BusId,
                currentLog.Latitude,
                currentLog.Longitude,
                destLat,
                destLon);

            if (googleEta.HasValue && googleEta.Value.RemainingSeconds > 0)
            {
                return new DestinationRemaining
                {
                    RemainingSeconds = googleEta.Value.RemainingSeconds,
                    RemainingMeters = googleEta.Value.RemainingMeters > 0
                        ? googleEta.Value.RemainingMeters
                        : (int)Math.Round(distanceToDestMeters),
                    Source = "google_directions",
                    EffectiveHeading = etaHeading
                };
            }

            return FromLocalEstimate(currentLog, polyline, startLat, startLon, endLat, endLon, routeDistanceKm, etaHeading);
        }

        private DestinationRemaining? FromLocalEstimate(
            BusLocationLog currentLog,
            IReadOnlyList<RoutePolylinePoint>? polyline,
            double? startLat,
            double? startLon,
            double? endLat,
            double? endLon,
            decimal? routeDistanceKm,
            int? heading)
        {
            var localEta = BusApproachCalculator.EstimateTimeToDestination(
                currentLog.Latitude,
                currentLog.Longitude,
                heading ?? currentLog.Heading,
                polyline,
                startLat,
                startLon,
                endLat,
                endLon,
                routeDistanceKm,
                currentLog.SpeedKmh);

            if (!localEta.HasValue)
                return null;

            return new DestinationRemaining
            {
                RemainingSeconds = localEta.Value.RemainingSeconds,
                RemainingMeters = localEta.Value.RemainingMeters,
                Source = "local",
                EffectiveHeading = heading ?? currentLog.Heading
            };
        }

        private async Task<GoogleDirectionsEta?> GetGoogleDrivingEtaAsync(
            int? busId,
            double originLat,
            double originLon,
            double destLat,
            double destLon)
        {
            return await GoogleDrivingEtaLookup.GetAsync(
                _configuration,
                _memoryCache,
                _logger,
                busId,
                originLat,
                originLon,
                destLat,
                destLon);
        }

        private async Task<bool> HasEmployeeBoardedTodayAsync(string userId, int? busId, int? routeId)
        {
            if (!int.TryParse(userId, out int employeeId))
                return false;

            var today = DateTime.Today;
            var query = _context.EmployeeBusLogs
                .AsNoTracking()
                .Where(e => e.EmployeeId == employeeId
                         && e.TripDate >= today
                         && e.TripDate < today.AddDays(1)
                         && e.BoardingTime != null);

            if (busId.HasValue)
                query = query.Where(e => e.BusId == busId.Value);

            if (routeId.HasValue)
                query = query.Where(e => e.RouteId == routeId.Value);

            return await query.AnyAsync();
        }

        private async Task<decimal> CalculateSpeedKmhAsync(
            int? busId,
            double latitude,
            double longitude,
            DateTime loggedAt,
            int? excludeLogId = null)
        {
            if (!busId.HasValue || latitude == 0 || longitude == 0)
                return 0;

            var previousQuery = _context.BusLocationLogs
                .AsNoTracking()
                .Where(l => l.BusId == busId.Value && !l.IsDeleted);

            if (excludeLogId.HasValue)
                previousQuery = previousQuery.Where(l => l.Id != excludeLogId.Value);

            var previous = await previousQuery
                .OrderByDescending(l => l.LoggedAt)
                .ThenByDescending(l => l.Id)
                .Select(l => new { l.Latitude, l.Longitude, l.LoggedAt })
                .FirstOrDefaultAsync();

            if (previous == null)
                return 0;

            return DistanceCalculator.CalculateSpeedKmh(
                previous.Latitude,
                previous.Longitude,
                previous.LoggedAt,
                latitude,
                longitude,
                loggedAt);
        }

        private static void TryParseLocationCoordinates(
            Location? location,
            out double? latitude,
            out double? longitude)
        {
            latitude = null;
            longitude = null;
            if (location == null)
                return;

            if (RoutePolylineHelper.TryParseCoordinate(location.Latitude, out double parsedLat))
                latitude = parsedLat;

            if (RoutePolylineHelper.TryParseCoordinate(location.Longitude, out double parsedLon))
                longitude = parsedLon;
        }

        private static BusLocationLiveDto MapToLiveDto(BusLocationLog log)
        {
            var route = log.Route ?? log.Bus?.Route;
            ApplyHeadingEndpoints(log.Heading, route, log.Source, out var source, out var destination);

            return new BusLocationLiveDto
            {
                BusCode = log.Bus?.Code,
                BusId = log.BusId,
                CreatedAt = log.LoggedAt,
                Destination = destination,
                Fullname = log.Driver != null
                    ? $"{log.Driver.FirstName} {log.Driver.LastName}".Trim()
                    : null,
                IsEnd = log.IsEnd,
                Lat = log.Latitude,
                Long = log.Longitude,
                Heading = log.Heading,
                Phone = log.Driver?.MobileNumber,
                PlateNumber = log.Bus?.PlateNumber,
                RouteId = log.RouteId ?? log.Bus?.RouteId,
                Source = source,
                TripNumber = log.TripNumber,
                Username = log.Driver?.UserName,
            };
        }

        private static void ApplyHeadingEndpoints(
            int? heading,
            Route? route,
            string? fallbackSource,
            out string? source,
            out string? destination)
        {
            var point1 = route?.StartLocation?.NameEn;
            var point2 = route?.EndLocation?.NameEn;

            if (heading == BusApproachCalculator.DirectionPoint2ToPoint1)
            {
                source = point2 ?? fallbackSource;
                destination = point1;
                return;
            }

            source = point1 ?? fallbackSource;
            destination = point2;
        }

        public static class DistanceCalculator
        {
            private const double EarthRadiusKm = 6371.0;
            private const double MinDistanceKm = 0.01;
            private const double MaxSpeedKmh = 120;

            public static double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
            {
                var dLat = ToRadians(lat2 - lat1);
                var dLon = ToRadians(lon2 - lon1);

                var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                        Math.Cos(ToRadians(lat1)) * Math.Cos(ToRadians(lat2)) *
                        Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

                var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

                return EarthRadiusKm * c; // النتيجة بالكيلومتر
            }

            public static decimal CalculateSpeedKmh(
                double previousLat,
                double previousLon,
                DateTime previousLoggedAt,
                double currentLat,
                double currentLon,
                DateTime currentLoggedAt)
            {
                if (previousLat == 0 || previousLon == 0 || currentLat == 0 || currentLon == 0)
                    return 0;

                var distanceKm = CalculateDistance(previousLat, previousLon, currentLat, currentLon);
                if (distanceKm < MinDistanceKm)
                    return 0;

                var hours = (currentLoggedAt - previousLoggedAt).TotalHours;
                if (hours <= 0)
                    return 0;

                var speed = distanceKm / hours;
                if (double.IsNaN(speed) || double.IsInfinity(speed) || speed < 0)
                    return 0;

                if (speed > MaxSpeedKmh)
                    speed = MaxSpeedKmh;

                return Math.Round((decimal)speed, 1);
            }

            private static double ToRadians(double angle) => (Math.PI / 180) * angle;
        }
    }
}
