﻿using Core.Helpers;
using DocumentFormat.OpenXml.Office2010.Excel;
using Mapster;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Extensions;
using Nupco.DAL.Models;
using Nupco.DAL.Models.Users;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Driver = Nupco.DAL.Models.Driver;

namespace Nupco.EF.Repositories
{
    internal class DriverRepository : BaseRepository<Driver>, IDriverRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly Driver_Assembler _Driver_Assembler;
        private readonly Bus_Assembler _Bus_Assembler;
        private readonly Route_Assembler _Route_Assembler;
        private readonly Location_Assembler _Location_Assembler;
        private readonly JWT _jwt;


        private string[] stringArray = { "Bus","Bus.Route"};


        public DriverRepository(ApplicationDbContext context, ILogger logger, JWT jwt) : base(context, logger)
        {
            _Driver_Assembler = new Driver_Assembler();
            _Bus_Assembler = new Bus_Assembler();
            _Route_Assembler = new Route_Assembler();
            _Location_Assembler = new Location_Assembler();
            _logger = logger;
            _context = context;
            _jwt = jwt;

        }

        public async Task<OperationOutput> GetDriverProfile(int driverId, string notificationToken)
        {
            var driver = await _context.Drivers.Include(i => i.Bus)
                .ThenInclude(i => i.Route)
                .ThenInclude(i => i.StartLocation)
                
                .Include(i => i.Bus)
                .ThenInclude(i => i.Route)
                .ThenInclude(i => i.EndLocation)
                .FirstOrDefaultAsync(f => f.Id == driverId);

            var lastLog = await _context.BusLocationLogs
                .Where(b => b.DriverId == driverId)       
                .OrderByDescending(b => b.Id).ThenByDescending(b=> b.LoggedAt)
                .FirstOrDefaultAsync();


            int? activeTripNumber = lastLog != null? lastLog.TripNumber: null;
            var driverDto = new DriverDetailsDto
            {
                Id = driver.Id,
                FullName = $"{driver.FirstName} {driver.LastName}",
                Phone = driver.MobileNumber,
                UserName = driver.UserName,
                NotificationToken = notificationToken,
                LastTripNumber = activeTripNumber,
                Bus = driver.Bus == null ? null : new BusDto
                {
                    Id = driver.Bus.Id,
                    BusNameAr = driver.Bus.NameAr,
                    BusNameEn = driver.Bus.NameEn,
                    PlateNumber = driver.Bus.PlateNumber,
                    Capacity = driver.Bus.Capacity.Value,
                    Code = driver.Bus.Code,
                    RouteId= driver.Bus.RouteId,
                    RouteNameAr = driver.Bus.Route?.NameAr,
                    RouteNameEn = driver.Bus.Route?.NameEn,
                    Route= driver.Bus.Route == null ? null : _Route_Assembler.WriteDto(driver.Bus.Route),
                    StatusStringAr = driver.IsActive == true ? "مفعل" : "غير مفعل",
                    StatusStringEn = driver.IsActive == true ? "Active" : "UnActive"
                }
            };

            driver.NotificationToken = notificationToken;
            Update(driver);
            await SaveChangesAsync();

            var token = GenerateToken(driver.Adapt<DriverDto>());
            var result = new 
            {
                Token = token,
                Driver = driverDto,
                NotificationToken = driver.NotificationToken
            };
            return new ResultOutputData().GenearetResultOutput(result, 1);

        }

        public async Task<OperationOutput> GenerateTokenDriver(int driverId)
        {
            try
            {
                var driver = await _context.Drivers.Include(i=> i.Bus).ThenInclude(i=> i.Route).FirstOrDefaultAsync(f => f.Id == driverId);
                var driverDto = new DriverDetailsDto
                {
                    Id = driver.Id,
                    FullName = $"{driver.FirstName} {driver.LastName}",
                    Phone = driver.MobileNumber,
                    UserName = driver.UserName,
                    Bus = driver.Bus == null ? null : new BusDto
                    {
                        Id = driver.Bus.Id,
                        BusNameAr = driver.Bus.NameAr,
                        BusNameEn = driver.Bus.NameEn,
                        PlateNumber = driver.Bus.PlateNumber,
                        Capacity = driver.Bus.Capacity.Value,
                        Code = driver.Bus.Code,
                        RouteNameAr = driver.Bus.Route?.NameAr,
                        RouteNameEn = driver.Bus.Route?.NameEn,
                        StatusStringAr = driver.IsActive == true ? "مفعل" : "غير مفعل",
                        StatusStringEn = driver.IsActive == true ? "Active" : "UnActive"
                    }
                };

                var token = GenerateToken(driver.Adapt<DriverDto>());
                var result = new DriverLoginResponseDto
                {
                    Token = token,
                    Driver = driverDto
                };
                return new ResultOutputData().GenearetResultOutput(result, 1);
            }
            catch (Exception)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> Login(string username, string password)
        {
            try
            {
                var driver = await _context.Drivers.AsNoTracking()
                    .Include(d => d.Bus)
                        .ThenInclude(b => b.Route)
                            .ThenInclude(r => r.StartLocation)
                    .Include(d => d.Bus)
                        .ThenInclude(b => b.Route)
                            .ThenInclude(r => r.EndLocation)
                    .FirstOrDefaultAsync(d =>
                        d.UserName == username &&
                        !d.IsDeleted);

                if (driver == null)
                    return ResultOutputData.GenearetResultOutputUserNotExist();

                if (AesEncryption.Decrypt(driver.Password) != password)
                    return ResultOutputData.GenearetResultOutputPasswordError();

                var driverDto = new DriverDetailsDto
                {
                    Id = driver.Id,
                    FullName = $"{driver.FirstName} {driver.LastName}",
                    Phone = driver.MobileNumber,
                    UserName = driver.UserName,
                    Bus = driver.Bus == null ? null : new BusDto
                    {
                        Id = driver.Bus.Id,
                        BusNameAr = driver.Bus.NameAr,
                        BusNameEn = driver.Bus.NameEn,
                        PlateNumber = driver.Bus.PlateNumber,
                        Capacity = driver.Bus.Capacity.Value,
                        Code = driver.Bus.Code,
                        RouteNameAr = driver.Bus.Route?.NameAr,
                        RouteNameEn = driver.Bus.Route?.NameEn
                    }
                };

                var result = new DriverLoginResponseDto
                {
                    Token ="",
                    Driver = driverDto
                };

                return new ResultOutputData().GenearetResultOutput(result, 1);

            }
            catch
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }



        }

        public string GenerateToken(DriverDto user)
        {
            try
            {
                var symmetricSecurityKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(_jwt.Key));
                var signingCredentials = new SigningCredentials(
                    symmetricSecurityKey, SecurityAlgorithms.HmacSha256);

                var jti = Guid.NewGuid().ToString();

                // Create claim in the format JWTHelper expects: "currentUser: {json}"
                string userJson = JsonConvert.SerializeObject(user);

                var claims = new List<Claim> {
            // This creates a claim with Type = "currentUser", Value = json
            new Claim(CustomType.currentUser, userJson),
            new Claim(JwtRegisteredClaimNames.Sid, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Jti, jti)
        };

                var expiry = DateTime.Now.AddMinutes(_jwt.DurationInMins);

                var token = new JwtSecurityToken(
                    issuer: _jwt.Issuer,
                    audience: _jwt.Audience,
                    claims: claims,
                    expires: expiry,
                    signingCredentials: signingCredentials);

                var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

                // Log for debugging
                _logger.LogInformation($"Token created for driver {user.Id} with JTI: {jti}");

                // Session management for drivers
                try
                {
                    using (var scope = new System.Transactions.TransactionScope(
                        System.Transactions.TransactionScopeAsyncFlowOption.Enabled))
                    {
                        // Check if DriverSessions table exists, if not you may need to create it
                        // For now, we'll assume you have a DriverSessions table similar to UserSessions

                        var oldSessions = _context.UserSessions?
                            .Where(x => x.DriverId == user.Id && x.IsActive == true)
                            .ToList();

                        if (oldSessions != null)
                        {
                            foreach (var session in oldSessions)
                            {
                                session.IsActive = false;
                                session.DeactivatedAt = DateTime.Now;
                                session.DeactivatedReason = "New login";
                            }
                        }

                        // Add new session - you may need to create a DriverSessions DbSet
                        // If DriverSessions doesn't exist, you can either:
                        // 1. Create a DriverSessions table similar to UserSessions
                        // 2. Use a different session tracking mechanism for drivers
                        // 3. Skip session management for drivers if not needed

                        // For now, let's comment this out until you decide on driver session management
                        
                        _context.UserSessions.Add(new UserSession
                        {
                            DriverId = user.Id,
                            SessionId = jti,
                            IsActive = true,
                            CreatedAt = DateTime.Now,
                            ExpiresAt = DateTime.Now.AddMinutes(_jwt.DurationInMins)
                        });
                        

                        _context.SaveChanges();
                        scope.Complete();

                        _logger.LogInformation($"Session managed for driver {user.Id} with JTI: {jti}");
                    }
                }
                catch (Exception ex)
                {
                    // Log but don't fail token generation if session management fails
                    _logger.LogWarning($"Session management for driver {user.Id} failed: {ex.Message}");
                }

                return Strings.CompressString(tokenString);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error creating JWT token for driver: {ex.Message}");
                throw new ApplicationException("An error occurred while creating the JWT token.", ex);
            }
        }

        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(DriverObjDto entity)
        {
            try
            {
                entity.IsActive = true;

                var model = _Driver_Assembler.WriteDal(entity);

                model.Password = AesEncryption.Encrypt(entity.Password);

                var _entity = await AddAsync(model);
                await _context.SaveChangesAsync();

                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(_entity, 1);
                return _result;
            }
            catch
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDeleted = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FiltersBy filter)
        {
            try
            {
                var spec = new DriverSpecification(filter);

                var skip = filter.pageNumber * filter.pageSize;
                var drivers = await FindAllAsync(spec.ToExpression(), filter.pageNumber, filter.pageSize, stringArray);
                var totalCount = await CountAsync();

                var driverDtos = _Driver_Assembler.WriteListDto(drivers);

                if (!driverDtos.Any())
                    return new ResultOutputData().GenearetResultOutput(driverDtos, 0);

                await ApplyLockoutStatusAsync(driverDtos);

                return new ResultOutputData().GenearetResultOutput(driverDtos, totalCount);
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        private async Task ApplyLockoutStatusAsync(List<DriverDto> dtos)
        {
            var usernames = dtos.Select(d => d.UserName).ToList();

            var lockedUsers = await _context.AccountLockouts
                .Where(l => usernames.Contains(l.Username))
                .Select(l => l.Username)
                .Union(
                    _context.LoginAttempts
                        .Where(a => usernames.Contains(a.Username))
                        .GroupBy(a => a.Username)
                        .Where(g => g.Count() >= 5)
                        .Select(g => g.Key)
                )
                .ToListAsync();

            foreach (var dto in dtos)
            {
                dto.IsLocked = lockedUsers.Contains(dto.UserName);
            }
        }
        public async Task<OperationOutput> GetBusesWithoutDriver()
        {
            try
            {
                var busesWithoutDriver = await _context.Buses
                    .Include(b => b.Drivers)
                    .Where(b =>
                        b.IsDeleted == false )
                    //    && (b.Drivers == null || !b.Drivers.Any(d => d.IsDeleted == false))
                    //)
                    .ToListAsync();

                var dtoList = _Bus_Assembler.WriteListDto(busesWithoutDriver);

                ResultOutputData resultOutput = new ResultOutputData();
                return resultOutput.GenearetResultOutput(dtoList, busesWithoutDriver.Count);
            }
            catch
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }


        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false,stringArray);
                var _entities = _Driver_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }
        public async Task<OperationOutput> GetDriversByBusId(int busId)
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false && i.BusId==busId,stringArray);
                var _entities = _Driver_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }



        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var Driver = await FindAsync(i=> i.Id==id, stringArray);
                if (Driver != null)
                {
                    var _Driver = _Driver_Assembler.WriteDto(Driver);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_Driver, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> UpdateEntity(DriverObjDto entity)
        {
            try
            {

                var _entity = await FindAsync(i => i.Id == entity.Id);
                if (_entity is not null)
                {

                    _entity.FirstName = entity.FirstName;
                    _entity.LastName = entity.LastName ;
                    _entity.LicenseNumber= entity.LicenseNumber;
                    _entity.VendorName = entity.VendorName;
                    _entity.MobileNumber = entity.MobileNumber;
                    _entity.UserName = entity.UserName;
                    _entity.BusId = entity.BusId;
                    if (!string.IsNullOrEmpty(entity.Password))
                    {
                        _entity.Password = AesEncryption.Encrypt(entity.Password);
                    }
                    var _model =  Update(_entity);
                    await SaveChangesAsync();

                    ResultOutputData resultOutput = new ResultOutputData();
                    var _result = resultOutput.GenearetResultOutput(_model, 1);
                    return _result;
                }

                else
                {
                    var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return Result;
                }

            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }

        public async Task<OperationOutput> UpadteDriverBusById(int id, int busId)
        {
            try
            {
                var driver = await GetByIdAsync(id);
                if (driver != null)
                {
                    driver.BusId = busId;

                    var _model = Update(driver);
                    await SaveChangesAsync();

                    var _Driver = _Driver_Assembler.WriteDto(_model);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_Driver, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> ChangePassowrdDriver(ChangePasswordDriver request)
        {
            try
            {
                var driver = await FindAsync(i => i.Id == request.Id && i.UserName==request.UserName);

                if (driver == null)
                    return ResultOutputData.GenearetResultOutputUserNotExist();

                // Compare old password
                var decryptedPassword = AesEncryption.Decrypt(driver.Password);
                if (decryptedPassword != request.OldPassword)
                    return ResultOutputData.GenearetResultOutputPasswordError();

                // Encrypt new password
                driver.Password = AesEncryption.Encrypt(request.NewPassword);

                var updated = Update(driver);
                await SaveChangesAsync();

                var dto = _Driver_Assembler.WriteDto(updated);

                return new ResultOutputData()
                    .GenearetResultOutput(dto, 1);
            }
            catch (Exception)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> UnLockedUser(int id , string username)
        {
            try
            {
                var _driver =await FindAsync(f => f.Id == id);
                if(_driver is null)
                    return ResultOutputData.GenearetResultOutputCatch();

                var accLockouts = await _context.AccountLockouts.Where(i => i.Username == username).ToListAsync();
                var loginAttempts = await _context.LoginAttempts.Where(i => i.Username == username).ToListAsync();
                if (accLockouts.Any())
                    _context.AccountLockouts.RemoveRange(accLockouts);

                if (loginAttempts.Any())
                    _context.LoginAttempts.RemoveRange(loginAttempts);

                await _context.SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;

            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }


        }

        public async Task<OperationOutput> SetNotificationToken(int driverId, string notificationToken)
        {
            try
            {
                var driver = await FindAsync(i => i.Id == driverId);
                if (driver is not null)
                {
                    driver.NotificationToken = notificationToken;
                    Update(driver);
                    await SaveChangesAsync();
                    return ResultOutputData.GenearetResultOutputSuccess();
                }
                return ResultOutputData.GenearetResultOutputUserNotExist();
            }
            catch (Exception)
            {
                return  ResultOutputData.GenearetResultOutputCatch();
            }

        }


        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(DriverDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<DriverDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<DriverDto> entities)
        {
            throw new NotImplementedException();
        }
    }

    public static class PasswordPolicyValidator
    {
        public static (bool IsValid, string ErrorMessage) ValidatePassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                return (false, "Password cannot be empty");

            // Minimum length check (adjust based on NUPCO policy)
            if (password.Length < 8)
                return (false, "Password must be at least 8 characters long");

            // Check for uppercase letter
            if (!password.Any(char.IsUpper))
                return (false, "Password must contain at least one uppercase letter");

            // Check for lowercase letter
            if (!password.Any(char.IsLower))
                return (false, "Password must contain at least one lowercase letter");

            // Check for digit
            if (!password.Any(char.IsDigit))
                return (false, "Password must contain at least one number");

            // Check for special character
            if (!password.Any(ch => !char.IsLetterOrDigit(ch)))
                return (false, "Password must contain at least one special character");

            return (true, string.Empty);
        }

    }
}
