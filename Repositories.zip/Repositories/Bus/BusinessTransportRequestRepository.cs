﻿using Core.Helpers;
using DocumentFormat.OpenXml.Office2010.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Mapster;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Nupco.EF.Repositories
{
    internal class BusinessTransportRequestRepository : BaseRepository<BusinessTransportRequest>, IBusinessTransportRequestRepository
    {
        private  readonly ApplicationDbContext _context;
        private  readonly ILogger _logger;
        private readonly BusinessTransportRequest_Assembler _BusinessTransportRequest_Assembler;

        private string[] stringArray = { "CreatedByUser", "UpdatedByUser", "ApproverDriver", "FromLocation", "ToLocation", "AssignedBus" };


        public BusinessTransportRequestRepository(ApplicationDbContext context, ILogger logger) : base(context, logger)
        {
            _BusinessTransportRequest_Assembler = new BusinessTransportRequest_Assembler();
            _logger = logger;
            _context = context;

            //var token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            //token = Core.Helpers.Strings.DecompressString(token);
            //var userInfo = Core.Helpers.JWTHelper.DecryptTokenUser(token);


        }

        public async Task<OperationOutput> ActivatedOrUnActivated(int id, bool activate)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsActive = activate;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> AddNewAsync(BusinessTransportRequestObjDto entity)
        {
            try
            {
                entity.IsActive = true;
                var _model = _BusinessTransportRequest_Assembler.WriteDal(entity);
                var _entity = await AddAsync(_model);
                await _context.SaveChangesAsync();


                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(_entity, 1);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> DeleteEntity(int id,string userId)
        {
            try
            {
                var find = await FindAsync(f => f.Id == id);
                find.IsDeleted = true;
                Update(find);
                await SaveChangesAsync();

                var Result = ResultOutputData.GenearetResultOutputSuccess();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FiltersBy _filter)
        {
            try
            {
                //var spec = Specification<BusinessTransportRequest>.All.And(new BusinessTransportRequestSpecification(_filter));

                var BusinessTransportRequest = await FindAllAsync(i => i.IsDeleted == false, (int)_filter.pageNumber * (int)_filter.pageSize, (int)_filter.pageSize,stringArray);
                var _BusinessTransportRequest = _BusinessTransportRequest_Assembler.WriteListDto(BusinessTransportRequest);
                var counts = await CountAsync(i => i.IsDeleted == false);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_BusinessTransportRequest, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetAllDataAsync()
        {
            try
            {

                var entities = await FindAllAsync(i => i.IsDeleted == false, stringArray);
                var _entities = _BusinessTransportRequest_Assembler.WriteListDto(entities);

                ResultOutputData resultOutput = new ResultOutputData();
                var count = await CountAsync(i => i.IsDeleted == false);
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetDataByIdAsync(int id)
        {
            try
            {
                var BusinessTransportRequest = await FindAsync(i=> i.Id==id , stringArray);
                if (BusinessTransportRequest != null)
                {
                    var _BusinessTransportRequest = _BusinessTransportRequest_Assembler.WriteDto(BusinessTransportRequest);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_BusinessTransportRequest, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> ApprovedByDriverId(int id, int driverId)
        {
            try
            {
                var BusinessTransportRequest = await FindAsync(i => i.Id == id, stringArray);
                if (BusinessTransportRequest != null)
                {
                    BusinessTransportRequest.AssignedDriverId = driverId;

                    var _model = Update(BusinessTransportRequest);
                    await SaveChangesAsync();

                    var _BusinessTransportRequest = _BusinessTransportRequest_Assembler.WriteDto(_model);
                    ResultOutputData result = new ResultOutputData();
                    var _result = result.GenearetResultOutput(_BusinessTransportRequest, 1);
                    return _result;
                }
                var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                return Result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }



        public async Task<OperationOutput> UpdateEntity(BusinessTransportRequestObjDto entity)
        {
            try
            {

                var _entity = await FindAsync(i => i.Id == entity.Id,stringArray);
                if (_entity is not null)
                {
                    _entity.IsActive = true;
                    _entity.IsDeleted = false;
                    _entity.AssignedDriverId = entity.AssignedDriverId;
                    _entity.AssignedBusId = entity.AssignedBusId;
                    _entity.FromLocationId = entity.FromLocationId;
                    _entity.Notes= entity.Notes;
                    _entity.ToLocationId = entity.ToLocationId;
                    _entity.Purpose = entity.Purpose;
                    _entity.UpdatedDate= DateTime.Now;
                    _entity.RequiredDateTime=entity.RequiredDateTime;
                    var _model =  Update(_entity);
                    await SaveChangesAsync();

                    var _BusinessTransportRequest = _BusinessTransportRequest_Assembler.WriteDto(_model);
                    ResultOutputData resultOutput = new ResultOutputData();
                    var _result = resultOutput.GenearetResultOutput(_BusinessTransportRequest, 1);
                    return _result;
                }

                else
                {
                    var Result = ResultOutputData.GenearetResultOutputNoDataReturned();
                    return Result;
                }

            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }

        }


        /// <summary>  /// </summary>

        public Task<OperationOutput> UpdateEntityAsync(BusinessTransportRequestDto t, object key)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> GetAllByUserIdAsync(string userId)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> DeleteEntityRange(IEnumerable<BusinessTransportRequestDto> entities)
        {
            throw new NotImplementedException();
        }
        public Task<OperationOutput> AddNewRangeAsync(IEnumerable<BusinessTransportRequestDto> entities)
        {
            throw new NotImplementedException();
        }
    }
}
