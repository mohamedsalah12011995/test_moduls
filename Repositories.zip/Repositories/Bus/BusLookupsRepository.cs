﻿using Core.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Nupco.EF.Repositories
{
    internal class BusLookupsRepository : IBusLookupsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;

        public BusLookupsRepository(ApplicationDbContext context, ILogger logger)
        {
            _logger = logger;
            _context = context;

        }

        public async Task<OperationOutput> GetBusStatusLookups()
        {
            try
            {

                var entities = await _context.BusStatusLookups.Where(i => i.IsDeleted == false).ToListAsync();
                var _entities = entities.Select(s => new
                {
                    Id = s.Id,
                    NameAr = s.NameAr,
                    NameEn = s.NameEn
                });

                ResultOutputData resultOutput = new ResultOutputData();
                var count = _entities.Count();
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetCallTypeLookups()
        {
            try
            {

                var entities = await _context.CallTypeLookups.Where(i => i.IsDeleted == false).ToListAsync();
                var _entities = entities.Select(s => new
                {
                    Id = s.Id,
                    NameAr = s.NameAr,
                    NameEn = s.NameEn
                });

                ResultOutputData resultOutput = new ResultOutputData();
                var count = _entities.Count();
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetComplaintCategoryLookups()
        {
            try
            {

                var entities = await _context.ComplaintCategoryLookups.Where(i => i.IsDeleted == false).ToListAsync();
                var _entities = entities.Select(s => new
                {
                    Id = s.Id,
                    NameAr = s.NameAr,
                    NameEn = s.NameEn
                });

                ResultOutputData resultOutput = new ResultOutputData();
                var count = _entities.Count();
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetComplaintStatusLookups()
        {
            try
            {

                var entities = await _context.ComplaintStatusLookups.Where(i => i.IsDeleted == false).ToListAsync();
                var _entities = entities.Select(s => new
                {
                    Id = s.Id,
                    NameAr = s.NameAr,
                    NameEn = s.NameEn
                });

                ResultOutputData resultOutput = new ResultOutputData();
                var count = _entities.Count();
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }

        public async Task<OperationOutput> GetBusAuditLogs()
        {
            try
            {

                var _entities = await _context.BusAuditLogs.ToListAsync();
                ResultOutputData resultOutput = new ResultOutputData();
                var count = _entities.Count();
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


    }
}
