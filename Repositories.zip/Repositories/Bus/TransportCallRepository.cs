﻿using Core.Helpers;
using Mapster;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Dto;
using Nupco.Core.Dto.Buses;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System.Globalization;
using static Google.Apis.Requests.BatchRequest;

namespace Nupco.EF.Repositories
{
    internal class TransportCallRepository : BaseRepository<TransportCall>, ITransportCallRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;
        private readonly TransportCall_Assembler _TransportCall_Assembler;
        private readonly NotifyMeRequest_Assembler _NotifyMeRequest_Assembler;
        private readonly Bus_Assembler _Bus_Assembler;
        private readonly JWT _jwt;


        private string[] stringArray = { " AssignedDriver" };


        public TransportCallRepository(ApplicationDbContext context, ILogger logger, JWT jwt) : base(context, logger)
        {
            _TransportCall_Assembler = new TransportCall_Assembler();
            _Bus_Assembler = new Bus_Assembler();
            _logger = logger;
            _context = context;
            _jwt = jwt;

        }

        public async Task<OperationOutput> ApproveRequestTransportCall(TransportCallApproval callApproval)
        {
            try
            {
                var requestCall = await _context.TransportCalls.FirstOrDefaultAsync(f => f.Id == callApproval.requestId);
                if (requestCall == null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                requestCall.StatusId = 2;
                requestCall.AssignedDriverId = callApproval.assignedDriverId;
                _context.Update(requestCall);
                await SaveChangesAsync();

                var dto = requestCall.Adapt<TransportCallDto>();
                await ApplyAssignedBusNamesAsync(dto, callApproval.assignedDriverId);

                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(dto, 1);
                return _result;
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();

            }


        }

        public async Task<OperationOutput> CreateTransportCall(TransportCallCreate request)
        {
            try
            {
                if (!TryParseCoordinate(request.Latitude, out var employeeLatitude) ||
                    !TryParseCoordinate(request.Longitude, out var employeeLongitude))
                {
                    return ResultOutputData.GenearetResultOutputUserNotExist();
                }

                var finalRouteId = request.RouteId;
                if (!finalRouteId.HasValue)
                {
                    return ResultOutputData.GenearetResultOutputNoDataReturned("Unable to detect route for current location");
                }

                // Upsert pending request so button flags stay consistent.
                // If user clicks again while there is already a pending call, we reset approach-notified state.
                var existingPendingCall = await _context.TransportCalls
                    .Where(tc =>
                        tc.RequestByUserId == request.UserId &&
                        tc.RouteId == finalRouteId.Value &&
                        tc.StatusId == 1 &&
                        // If TripNumber is null in request, match "null trip" calls.
                        ((tc.TripNumber == request.TripNumber) ||
                         (!tc.TripNumber.HasValue && !request.TripNumber.HasValue)))
                    .OrderByDescending(tc => tc.Id)
                    .FirstOrDefaultAsync();

                var driverInfos = await ResolveDriversForRouteAndReverseAsync(finalRouteId.Value);

                TransportCall transportCall;
                if (existingPendingCall != null)
                {
                    transportCall = existingPendingCall;
                    transportCall.TripNumber = request.TripNumber;
                    transportCall.Latitude = request.Latitude;
                    transportCall.Longitude = request.Longitude;
                    transportCall.Note = request.Note;
                    transportCall.RouteId = finalRouteId.Value;
                    transportCall.StatusId = 1;
                    transportCall.CallTime = DateTime.Now;
                    transportCall.AssignedDriverId = null;
                    transportCall.IsApproachNotified = false;
                    transportCall.ApproachNotifiedDate = null;

                    _context.TransportCalls.Update(transportCall);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    transportCall = new TransportCall
                    {
                        TripNumber = request.TripNumber,
                        RequestByUserId = request.UserId,
                        Latitude = request.Latitude,
                        Longitude = request.Longitude,
                        Note = request.Note,
                        RouteId = finalRouteId.Value,
                        StatusId = 1,
                        CallTime = DateTime.Now,
                        AssignedDriverId = null
                    };

                    await _context.TransportCalls.AddAsync(transportCall);
                    await _context.SaveChangesAsync();
                }

                var distinctNotifiedDrivers = driverInfos
                    .Where(x => !string.IsNullOrEmpty(x.Item2))
                    .GroupBy(x => x.Item1)
                    .Select(g => g.First())
                    .ToList();

                var notifiedDriverIds = distinctNotifiedDrivers
                    .Select(x => (int?)x.Item1)
                    .ToList();

                var notificationsList = distinctNotifiedDrivers
                    .Select(x => new NotificationWithLanaguge(x.Item2, "ar"))
                    .ToList();

                try
                {
                    await LogBusCallAsync(request, finalRouteId.Value, notifiedDriverIds.FirstOrDefault(), employeeLatitude, employeeLongitude);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to log BusCall for user {UserId}, route {RouteId}", request?.UserId, finalRouteId.Value);
                }

                var TCResponse = new TransportCallResponse
                {
                    TransportCallId = transportCall.Id,
                    userId = request.UserId,
                    notifiedDriverIds = notifiedDriverIds,
                    notificationTokens = notificationsList
                };

                ResultOutputData result = new ResultOutputData();
                return result.GenearetResultOutput(TCResponse, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateTransportCall failed for user {UserId}, route {RouteId}", request?.UserId, request?.RouteId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        private async Task<int?> DetectNearestRouteIdAsync(double employeeLatitude, double employeeLongitude)
        {
            var routePointCandidates = new List<(int RouteId, double Latitude, double Longitude)>();

            var activeRoutes = await _context.Routes
                .AsNoTracking()
                .Where(r => r.IsActive && !r.IsDeleted)
                .Select(r => new { r.Id, r.StartLocationId, r.EndLocationId })
                .ToListAsync();

            var activeRouteIds = activeRoutes.Select(r => r.Id).ToHashSet();

            var routeStops = await _context.RouteStops
                .AsNoTracking()
                .Join(
                    _context.Locations.AsNoTracking(),
                    rs => rs.LocationId,
                    l => l.Id,
                    (rs, l) => new { rs.RouteId, Location = l })
                .Where(x => activeRouteIds.Contains(x.RouteId) && x.Location.IsActive && !x.Location.IsDeleted)
                .ToListAsync();

            foreach (var stop in routeStops)
            {
                if (TryParseCoordinate(stop.Location.Latitude, out var lat) &&
                    TryParseCoordinate(stop.Location.Longitude, out var lon))
                {
                    routePointCandidates.Add((stop.RouteId, lat, lon));
                }
            }

            var locationIds = activeRoutes
                .SelectMany(r => new[] { r.StartLocationId, r.EndLocationId })
                .Where(id => id.HasValue)
                .Select(id => id!.Value)
                .Distinct()
                .ToList();

            var routeLocations = await _context.Locations
                .AsNoTracking()
                .Where(l => locationIds.Contains(l.Id) && l.IsActive && !l.IsDeleted)
                .Select(l => new { l.Id, l.Latitude, l.Longitude })
                .ToListAsync();

            var locationMap = routeLocations.ToDictionary(l => l.Id, l => l);

            foreach (var route in activeRoutes)
            {
                if (route.StartLocationId.HasValue &&
                    locationMap.TryGetValue(route.StartLocationId.Value, out var startLocation) &&
                    TryParseCoordinate(startLocation.Latitude, out var startLat) &&
                    TryParseCoordinate(startLocation.Longitude, out var startLon))
                {
                    routePointCandidates.Add((route.Id, startLat, startLon));
                }

                if (route.EndLocationId.HasValue &&
                    locationMap.TryGetValue(route.EndLocationId.Value, out var endLocation) &&
                    TryParseCoordinate(endLocation.Latitude, out var endLat) &&
                    TryParseCoordinate(endLocation.Longitude, out var endLon))
                {
                    routePointCandidates.Add((route.Id, endLat, endLon));
                }
            }

            if (routePointCandidates.Count == 0)
            {
                return null;
            }

            var nearestRoute = routePointCandidates
                .Select(candidate => new
                {
                    candidate.RouteId,
                    Distance = GeoDistanceCalculator.CalculateHaversineDistance(
                        employeeLatitude, employeeLongitude,
                        candidate.Latitude, candidate.Longitude)
                })
                .OrderBy(x => x.Distance)
                .FirstOrDefault();

            return nearestRoute?.RouteId;
        }

        /// <summary>
        /// All active drivers working on active buses for either the same route pair
        /// (start->end) or reverse pair (end->start).
        /// </summary>
        private async Task<List<(int DriverId, string? NotificationToken)>> ResolveDriversForRouteAndReverseAsync(int receivedRouteId)
        {
            var receivedRoute = await _context.Routes
                .AsNoTracking()
                .Where(r => r.Id == receivedRouteId && r.IsActive && !r.IsDeleted)
                .Select(r => new { r.StartLocationId, r.EndLocationId })
                .FirstOrDefaultAsync();

            if (receivedRoute == null || !receivedRoute.StartLocationId.HasValue || !receivedRoute.EndLocationId.HasValue)
                return new List<(int DriverId, string? NotificationToken)>();

            var startLoc = receivedRoute.StartLocationId.Value;
            var endLoc = receivedRoute.EndLocationId.Value;

            var matchingRouteIds = await _context.Routes
                .AsNoTracking()
                .Where(r => r.IsActive && !r.IsDeleted &&
                    ((r.StartLocationId == startLoc && r.EndLocationId == endLoc) ||
                     (r.StartLocationId == endLoc && r.EndLocationId == startLoc)))
                .Select(r => r.Id)
                .ToListAsync();

            if (matchingRouteIds.Count == 0)
                return new List<(int DriverId, string? NotificationToken)>();

            var busIds = await _context.Buses
                .AsNoTracking()
                .Where(b =>
                    b.RouteId.HasValue &&
                    matchingRouteIds.Contains(b.RouteId.Value) &&
                    b.IsActive &&
                    !b.IsDeleted)
                .Select(b => b.Id)
                .ToListAsync();

            if (busIds.Count == 0)
                return new List<(int DriverId, string? NotificationToken)>();

            return await _context.Drivers
                .AsNoTracking()
                .Where(d =>
                    d.BusId.HasValue &&
                    busIds.Contains(d.BusId.Value) &&
                    d.IsActive &&
                    !d.IsDeleted)
                .OrderBy(d => d.Id)
                .Select(d => new ValueTuple<int, string?>(d.Id, d.NotificationToken))
                .ToListAsync();
        }

        private async Task LogBusCallAsync(TransportCallCreate request, int routeId, int? firstRelatedDriverId, double employeeLatitude, double employeeLongitude)
        {
            var nearestLocation = await GetNearestLocationAsync(employeeLatitude, employeeLongitude);
            var callTypeId = await ResolveBusCallTypeIdAsync();
            int.TryParse(request.UserId, out var employeeId);

            var busCall = new BusCall
            {
                RouteId = routeId,
                EmployeeId = employeeId > 0 ? employeeId : null,
                DriverId = firstRelatedDriverId,
                CallerType = "Employee",
                CallTypeId = callTypeId,
                Description = BuildBusCallDescription(request.Note, nearestLocation),
                CallTime = DateTime.Now,
                Status = "OPEN"
            };

            await _context.BusCalls.AddAsync(busCall);
            await _context.SaveChangesAsync();
        }

        private async Task<Location?> GetNearestLocationAsync(double employeeLatitude, double employeeLongitude)
        {
            var allLocations = await _context.Locations
                .AsNoTracking()
                .Where(l => l.IsActive && !l.IsDeleted)
                .ToListAsync();

            Location? nearest = null;
            var minDistance = double.MaxValue;

            foreach (var location in allLocations)
            {
                if (!TryParseCoordinate(location.Latitude, out var locationLatitude) ||
                    !TryParseCoordinate(location.Longitude, out var locationLongitude))
                {
                    continue;
                }

                var distance = GeoDistanceCalculator.CalculateHaversineDistance(
                    employeeLatitude, employeeLongitude,
                    locationLatitude, locationLongitude);

                if (distance < minDistance)
                {
                    minDistance = distance;
                    nearest = location;
                }
            }

            return nearest;
        }

        private async Task<int> ResolveBusCallTypeIdAsync()
        {
            var transportCallType = await _context.CallTypeLookups
                .AsNoTracking()
                .Where(c => c.IsActive && !c.IsDeleted &&
                            (Microsoft.EntityFrameworkCore.EF.Functions.Like(c.Code, "%TRANSPORT%") || Microsoft.EntityFrameworkCore.EF.Functions.Like(c.NameEn, "%transport%")))
                .OrderBy(c => c.Id)
                .Select(c => c.Id)
                .FirstOrDefaultAsync();

            if (transportCallType > 0)
            {
                return transportCallType;
            }

            var fallback = await _context.CallTypeLookups
                .AsNoTracking()
                .OrderBy(c => c.Id)
                .Select(c => c.Id)
                .FirstOrDefaultAsync();

            if (fallback > 0)
            {
                return fallback;
            }

            var fallbackActive = await _context.CallTypeLookups
                .AsNoTracking()
                .Where(c => c.IsActive && !c.IsDeleted)
                .OrderBy(c => c.Id)
                .Select(c => c.Id)
                .FirstOrDefaultAsync();

            if (fallbackActive > 0)
            {
                return fallbackActive;
            }

            var defaultCallType = new CallTypeLookup
            {
                Code = "TRANSPORT_CALL",
                NameAr = "طلب نقل",
                NameEn = "Transport Call",
                Description = "Auto-created default call type for transport calls",
                IsActive = true,
                IsDeleted = false
            };

            await _context.CallTypeLookups.AddAsync(defaultCallType);
            await _context.SaveChangesAsync();

            return defaultCallType.Id;
        }

        private static string BuildBusCallDescription(string? note, Location? nearestLocation)
        {
            if (nearestLocation == null)
            {
                return note ?? "Transport call created";
            }

            var locationName = !string.IsNullOrWhiteSpace(nearestLocation.NameEn)
                ? nearestLocation.NameEn
                : nearestLocation.NameAr;

            if (string.IsNullOrWhiteSpace(note))
            {
                return $"Nearest location: {locationName}";
            }

            return $"{note} | Nearest location: {locationName}";
        }

        private static bool TryParseCoordinate(string? value, out double coordinate)
        {
            coordinate = 0;
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            return double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out coordinate) ||
                   double.TryParse(value, NumberStyles.Float, CultureInfo.CurrentCulture, out coordinate);
        }
        private double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
        {
            var R = 6371;
            var dLat = ToRadians(lat2 - lat1);
            var dLon = ToRadians(lon2 - lon1);
            var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                    Math.Cos(ToRadians(lat1)) * Math.Cos(ToRadians(lat2)) *
                    Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
            var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            return R * c;
        }

        private double ToRadians(double angle) => (Math.PI / 180) * angle;


        public async Task<List<DriverLocationDto>> GetLatestDriversLocationsAsync()
        {
            var drivers = await _context.BusLocationLogs
            .AsNoTracking()
            .Where(l => l.IsActive && !l.IsDeleted)
            .GroupBy(l => l.DriverId)
            .Select(group => group
                .OrderByDescending(x => x.LoggedAt)
                .Select(x => new DriverLocationDto
                {
                    DriverId = x.DriverId ?? 0,
                    Latitude = x.Latitude.ToString(),
                    Longitude = x.Longitude.ToString()
                })
                .FirstOrDefault()
            )
            .Where(x => x != null)
            .ToListAsync();

            return drivers;
        }

        public async Task<OperationOutput> GetAllByPagenationForMobile(TransportCallFillter _filter)
        {
            try
            {
                var spec = new TransportCallSpecification(_filter);
                var today = DateTime.Today;
                var tomorrow = today.AddDays(1);

                var query = _context.TransportCalls.Where(spec.ToExpression()).Where(i=> i.CallTime.Date==DateTime.Now.Date);
                //query = query.Where(i => i.CallTime.Date==DateTime.Now.Date);
                query = query.Where(i => i.CallTime >= today && i.CallTime < tomorrow );

                var totalCounts = await query.CountAsync();

                int size = _filter.pageSize ?? 10;
                int pageIndex = _filter.pageNumeber ?? 0;
                int skipCount = Math.Max(0, pageIndex) * size;

                var data = await query
                    .Include(i => i.AssignedDriver)
                    .Include(i => i.Route)
                    .Include(i => i.RequestByUser)
                    .OrderByDescending(x => x.Id)
                    .Skip(skipCount)
                    .Take(size)
                    .ToListAsync();

                var mappedData = _TransportCall_Assembler.WriteListDto(data);

                ResultOutputData resultHelper = new ResultOutputData();
                return resultHelper.GenearetResultOutput(mappedData, totalCounts);
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }


        public async Task<OperationOutput> GetAllByPagenationForAdmin(TransportCallFillter _filter)
        {
            try
            {
                var spec = new TransportCallSpecification(_filter);
                var query = _context.TransportCalls.Where(spec.ToExpression());
                var totalCounts = await query.CountAsync();

                int size = _filter.pageSize ?? 10;
                int pageIndex = _filter.pageNumeber ?? 0;
                int skipCount = Math.Max(0, pageIndex) * size;

                var data = await query
                    .Include(i => i.AssignedDriver)
                    .Include(i => i.Route)
                    .Include(i => i.RequestByUser)
                    .OrderByDescending(x => x.Id)
                    .Skip(skipCount)
                    .Take(size)
                    .ToListAsync();

                var mappedData = _TransportCall_Assembler.WriteListDto(data);

                ResultOutputData resultHelper = new ResultOutputData();
                return resultHelper.GenearetResultOutput(mappedData, totalCounts);
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> GetAllTransportCall()
        {
            try
            {
                var data = await _context.TransportCalls.Include(i => i.AssignedDriver).ThenInclude(d => d.Bus).Include(i=> i.Route).Include(i=> i.RequestByUser)
                 .OrderByDescending(x => x.Id).AsNoTracking().ToListAsync();

                var mappedData = _TransportCall_Assembler.WriteListDto(data);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(mappedData, mappedData.Count());
                return _result;

            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        public async Task<OperationOutput> GetAllByPagenationNotifyMeRequests(NotifyMeRequestFillter _filter)
        {
            try
            {
                var spec = new NotifyMeRequestsSpecification(_filter);
                var query = _context.NotifyMeRequests.Where(spec.ToExpression());
                var totalCounts = await query.CountAsync();

                int size = _filter.pageSize ?? 10;
                int pageIndex = _filter.pageNumeber ?? 0;
                int skipCount = Math.Max(0, pageIndex) * size;

                var data = await query
                    .Include(i => i.AssignedDriver)
                    .Include(i => i.Route)
                    .Include(i => i.RequestByUser)
                    .OrderByDescending(x => x.Id)
                    .Skip(skipCount)
                    .Take(size)
                    .ToListAsync();

                var mappedData = _NotifyMeRequest_Assembler.WriteListDto(data);

                ResultOutputData resultHelper = new ResultOutputData();
                return resultHelper.GenearetResultOutput(mappedData, totalCounts);
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        private async Task ApplyAssignedBusNamesAsync(TransportCallDto dto, int assignedDriverId)
        {
            var bus = await _context.Drivers
                .AsNoTracking()
                .Where(d => d.Id == assignedDriverId)
                .Select(d => d.Bus)
                .FirstOrDefaultAsync();

            if (bus == null)
                return;

            dto.BusNameAr = bus.NameAr;
            dto.BusNameEn = bus.NameEn;
            dto.BusCode = bus.Code;
            dto.PlateNumber = bus.PlateNumber;
        }
    }
}
