﻿using Core.Helpers;
using Mapster;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Dto;
using Nupco.Core.Dto.Buses;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;

namespace Nupco.EF.Repositories
{
    internal class NotifyMeRequestRepository : BaseRepository<NotifyMeRequest>, INotifyMeRequestRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;
        private readonly NotifyMeRequest_Assembler _NotifyMeRequest_Assembler;
        private readonly Bus_Assembler _Bus_Assembler;
        private readonly JWT _jwt;


        private string[] stringArray = { " AssignedDriver" };


        public NotifyMeRequestRepository(ApplicationDbContext context, ILogger logger, JWT jwt) : base(context, logger)
        {
            _NotifyMeRequest_Assembler = new NotifyMeRequest_Assembler();
            _Bus_Assembler = new Bus_Assembler();
            _logger = logger;
            _context = context;
            _jwt = jwt;

        }

        public async Task<OperationOutput> CreateNotifyMeRequest(CreateNotifyMeRequestDto dto)
        {
            try
            {
                // Check existing request by UserId and RouteId
                var existingRequest = await _context.NotifyMeRequests
                    .FirstOrDefaultAsync(x => x.RequestByUserId == dto.RequestByUserId
                                           && x.RouteId == dto.RouteId && x.TripNumber == dto.TripNumber);

                NotifyMeRequest resultEntity;

                if (existingRequest != null)
                {
                    // Reset notification status if existing request re-enables
                    existingRequest.IsApproachNotified = false;
                    existingRequest.ApproachNotifiedDate = null;
                    existingRequest.TripNumber = dto.TripNumber;
                    existingRequest.Latitude = dto.Latitude;
                    existingRequest.Longitude = dto.Longitude;
                    existingRequest.AssignedDriverId = dto.AssignedDriverId;
                    existingRequest.Note = dto.Note;

                    resultEntity = existingRequest;
                }
                else
                {
                    // Create new NotifyMeRequest
                    var newRequest = new NotifyMeRequest
                    {
                        RequestByUserId = dto.RequestByUserId,
                        RouteId = dto.RouteId,
                        AssignedDriverId = dto.AssignedDriverId,
                        TripNumber = dto.TripNumber,
                        Latitude = dto.Latitude,
                        Longitude = dto.Longitude,
                        Note = dto.Note,
                        CallTime = DateTime.UtcNow,
                        IsApproachNotified = false
                    };

                    await _context.NotifyMeRequests.AddAsync(newRequest);
                    resultEntity = newRequest;
                }

                await _context.SaveChangesAsync();

                return new ResultOutputData().GenearetResultOutput(resultEntity, 1);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating NotifyMe status for UserId: {UserId}", dto.RequestByUserId);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }


        public async Task<OperationOutput> ApproveRequestNotifyMeRequest(NotifyMeRequestApproval callApproval)
        {
            try
            {
                var requestCall = await _context.NotifyMeRequests.FirstOrDefaultAsync(f => f.Id == callApproval.requestId);
                if (requestCall == null)
                    return ResultOutputData.GenearetResultOutputNoDataReturned();

                requestCall.StatusId = 2;
                requestCall.AssignedDriverId = callApproval.assignedDriverId;
                _context.Update(requestCall);
                await SaveChangesAsync();

                var dto = requestCall.Adapt<NotifyMeRequestDto>();
                await ApplyAssignedBusNamesAsync(dto, callApproval.assignedDriverId);

                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(dto, 1);
                return _result;
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();

            }


        }


        public async Task<OperationOutput> GetAllByPagenationForAdmin(NotifyMeRequestFillter _filter)
        {
            try
            {
                var spec = new NotifyMeRequestsSpecification(_filter);
                var query = _context.NotifyMeRequests.Where(spec.ToExpression());
                var totalCounts = await query.CountAsync();

                int size = _filter.pageSize ?? 10;
                int pageIndex = _filter.pageNumeber ?? 0;
                int skipCount = Math.Max(0, pageIndex) * size;

                var data = await query
                    .Include(i => i.AssignedDriver).ThenInclude(d => d.Bus)
                    .Include(i => i.Route)
                    .Include(i => i.RequestByUser)
                    .OrderByDescending(x => x.Id)
                    .Skip(skipCount)
                    .Take(size)
                    .ToListAsync();

                var mappedData = _NotifyMeRequest_Assembler.WriteListDto(data);

                ResultOutputData resultHelper = new ResultOutputData();
                return resultHelper.GenearetResultOutput(mappedData, totalCounts);
            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }
        public async Task<OperationOutput> GetAllNotifyMeRequest()
        {
            try
            {
                var data = await _context.NotifyMeRequests.Include(i => i.AssignedDriver).ThenInclude(d => d.Bus).Include(i=> i.Route).Include(i=> i.RequestByUser)
                 .OrderByDescending(x => x.Id).AsNoTracking().ToListAsync();

                var mappedData = _NotifyMeRequest_Assembler.WriteListDto(data);
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(mappedData, mappedData.Count());
                return _result;

            }
            catch (Exception ex)
            {
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

        private async Task ApplyAssignedBusNamesAsync(NotifyMeRequestDto dto, int assignedDriverId)
        {
            var bus = await _context.Drivers
                .AsNoTracking()
                .Where(d => d.Id == assignedDriverId)
                .Select(d => d.Bus)
                .FirstOrDefaultAsync();

            if (bus == null)
                return;

            dto.BusNameAr = bus.NameAr;
            dto.BusNameEn = bus.NameEn;
            dto.BusCode = bus.Code;
            dto.PlateNumber = bus.PlateNumber;
        }


    }
}
