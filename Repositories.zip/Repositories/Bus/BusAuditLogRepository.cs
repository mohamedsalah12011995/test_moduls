﻿using Core.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nupco.Core;
using Nupco.Core.Assembler;
using Nupco.Core.Consts;
using Nupco.Core.Dto;
using Nupco.Core.Helpers;
using Nupco.Core.Interfaces;
using Nupco.DAL;
using Nupco.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using YourProject.DAL.Models.Buses;
using Location = Nupco.DAL.Models.Location;

namespace Nupco.EF.Repositories
{
    internal class BusAuditLogsRepository : IBusAuditLogsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger _logger;

        public BusAuditLogsRepository(ApplicationDbContext context, ILogger logger)
        {
            _logger = logger;
            _context = context;

        }

        public async Task<OperationOutput> GetAllByPagenationAsync(FilterByBusAduitLog _filter)
        {
            try
            {
                var spec = Specification<BusAuditLog>.All.And(new BusAuditLogsSpecification(_filter));

                var _BusAuditLogs = await _context.BusAuditLogs.Where(spec.ToExpression())
                                           .OrderByDescending(o => o.Id)
                                           .Skip((int)_filter.pageNumber * (int)_filter.pageSize).Take((int)_filter.pageSize)
                                           .AsNoTrackingWithIdentityResolution().ToListAsync();

                var counts =await _context.BusAuditLogs.CountAsync();
                ResultOutputData result = new ResultOutputData();
                var _result = result.GenearetResultOutput(_BusAuditLogs, counts);
                return _result;
            }
            catch (Exception)
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }





        public async Task<OperationOutput> GetBusAuditLogs()
        {
            try
            {

                var _entities = await _context.BusAuditLogs.ToListAsync();
                ResultOutputData resultOutput = new ResultOutputData();
                var count = _entities.Count();
                var _result = resultOutput.GenearetResultOutput(_entities, count);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> GetBusLookUpsLogs()
        {
            try
            {

                var lookupData = await _context.BusAuditLogs
                             .GroupBy(x => new { x.ModulNameAr, x.ModulNameEn })
                             .Select(g => g.Key)
                             .AsNoTracking()
                             .ToListAsync();

                var operations = await _context.BusAuditLogs
                    .Select(x => x.Operation)
                    .Distinct()
                    .AsNoTracking()
                    .ToListAsync();

                var LookupsList = new { lookupData, operations };

                ResultOutputData resultOutput = new ResultOutputData();
                var _result = resultOutput.GenearetResultOutput(LookupsList, 1);
                return _result;
            }
            catch
            {
                var Result = ResultOutputData.GenearetResultOutputCatch();
                return Result;
            }
        }


        public async Task<OperationOutput> GetLookUpsByModuleNameWithAuditLogs(string module)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(module))
                    return ResultOutputData.GenearetResultOutputCatch();

                var moduleLower = module.ToLower();

                // 1️⃣ Get all audit log RecordIds for the module
                var auditRecordIds = await _context.BusAuditLogs
                    .Where(al => al.ModulNameEn.ToLower() == moduleLower)
                    .Select(al => al.RecordId).Distinct()
                    .ToListAsync();

                object lookupsList = null;

                // 2️⃣ Filter entities by auditRecordIds
                switch (moduleLower)
                {
                    case "buses":
                        var lookupBuses = await _context.Buses
                            .AsNoTracking()
                            .Where(b => !b.IsDeleted && auditRecordIds.Contains(b.Id.ToString()))
                            .Select(b => new { b.Id, b.NameAr, b.NameEn })
                            .ToListAsync();

                        lookupsList = new { lookupBuses };
                        break;

                    case "drivers":
                        var lookupDrivers = await _context.Drivers
                            .AsNoTracking()
                            .Where(d => !d.IsDeleted && auditRecordIds.Contains(d.Id.ToString()))
                            .Select(d => new { d.Id, d.FirstName, d.LastName, d.UserName })
                            .ToListAsync();

                        lookupsList = new { lookupDrivers };
                        break;

                    case "routes":
                        var lookupRoutes = await _context.Routes
                            .AsNoTracking()
                            .Where(r => !r.IsDeleted && auditRecordIds.Contains(r.Id.ToString()))
                            .Select(r => new { r.Id, r.NameAr, r.NameEn })
                            .ToListAsync();

                        lookupsList = new { lookupRoutes };
                        break;

                    case "locations":
                        var lookupLocations = await _context.Locations
                            .AsNoTracking()
                            .Where(l => !l.IsDeleted && auditRecordIds.Contains(l.Id.ToString()))
                            .Select(l => new { l.Id, l.NameAr, l.NameEn })
                            .ToListAsync();

                        lookupsList = new { lookupLocations };
                        break;
                    case "businesstransportrequests":
                        var businessTransportRequests = await _context.BusinessTransportRequests
                            .Include(b => b.FromLocation)
                            .Include(b => b.ToLocation)
                            .AsNoTracking()
                            .Where(l => !l.IsDeleted && auditRecordIds.Contains(l.Id.ToString()))
                            .Select(l => new
                            {
                                id = l.Id,
                                FromNameAr = l.FromLocation.NameAr,
                                FromNameEn = l.FromLocation.NameEn,
                                ToNameAr = l.ToLocation.NameAr,
                                ToNameEn = l.ToLocation.NameEn
                            })
                            .ToListAsync();

                        lookupsList = new { businessTransportRequests };
                        break;


                    default:
                        lookupsList = null;
                        break;
                }

                return new ResultOutputData().GenearetResultOutput(lookupsList, 1);
            }
            catch (Exception ex)
            {
                //_logger.LogError(ex, "Error fetching lookups by module with audit logs {Module}", module);
                return ResultOutputData.GenearetResultOutputCatch();
            }
        }

    }
}
